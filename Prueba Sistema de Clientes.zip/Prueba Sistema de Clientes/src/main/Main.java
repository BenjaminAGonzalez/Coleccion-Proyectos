package main;

import vista.Menu;

public class Main {

	public static void main(String[] args) {
		
		Menu menu = new Menu(); //Instancio menu
		
		menu.iniciarMenu(); //Entro a clase menu 
		
	}

}
