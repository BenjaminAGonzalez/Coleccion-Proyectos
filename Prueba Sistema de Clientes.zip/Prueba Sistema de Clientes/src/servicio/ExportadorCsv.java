/**
 * 
 */
package servicio;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.List;
import java.util.Scanner;

import modelo.Cliente;

/**
 * @author Benja
 *
 */
public class ExportadorCsv extends Exportador {

	Scanner scanner = new Scanner(System.in);

	@Override
	public void exportar(String fileName, List<Cliente> listaClientes) {

		if(listaClientes.size()==0) { //Si la lista esta vacia, no puedo exportarla
			System.out.println("La lista se encuentra vacia, por favor, ingrese clientes a la lista");
		}
		else {
			String separador =  ",";
			System.out.println("Ingrese la ruta donde se exportara el archivo .csv, si este ya existe, se sobreescribira");
			String ruta = scanner.nextLine();
			String archivo = ruta + "/" + fileName;

			File crearArchivo = new File(archivo);
			try {
				if(crearArchivo.exists()) { //Si el archivo ya existe, se sobreescribira
					crearArchivo.delete();
				}
				FileWriter escritor = new FileWriter (crearArchivo);
				BufferedWriter escritorb = new BufferedWriter (escritor);

				for(Cliente cliente: listaClientes) {
					escritorb.append(cliente.getRunCliente()).append(separador).append(cliente.getNombreCliente()).append(separador).append(cliente.getApellidoCliente())
					.append(separador).append(cliente.getAniosCliente()); //Agregamos cada dato separado por una coma
					escritorb.newLine();
				}
				escritorb.close();
				System.out.println("Datos correctamente exportados a .csv");
			}catch(Exception error) {
				System.out.println("Hubo un error en la exportacion de datos. Favor confirmar la ruta o nombre de archivo ingresados. Mensaje de error: " + error.getMessage());
			}
		}
	}
}
