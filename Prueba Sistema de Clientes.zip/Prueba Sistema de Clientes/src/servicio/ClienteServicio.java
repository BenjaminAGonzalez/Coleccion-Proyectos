/**
 * 
 */
package servicio;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import modelo.Cliente;
import utilidades.Utilidad;

/**
 * @author Benja
 *
 */
public class ClienteServicio {

	List<Cliente> listaClientes;

	public ClienteServicio() {
		listaClientes = new ArrayList<>();
	}

	public void listarClientes() {

		if(listaClientes.size()!=0) { //Listo todos los clientes solo si la lista no esta vacia

			for(Cliente cliente : listaClientes) {
				System.out.println("--------------Datos de clientes--------------");
				System.out.println("RUN Cliente: " + cliente.getRunCliente());
				System.out.println("Nombre Cliente: " + cliente.getNombreCliente());
				System.out.println("Apellido Cliente: " + cliente.getApellidoCliente());
				System.out.println("A�os de permanencia del cliente: " + cliente.getAniosCliente());
				System.out.println();
				Utilidad.espera();
			}	
		}else {
			System.out.println("La lista no puede mostrarse debido a que no posee clientes. Favor agregue clientes");
		}
		Utilidad.EsperaYLimpieza();
	}

	public void agregarCliente(String runCliente, String nombreCliente, String apellidoCliente, String aniosCliente) {

		Cliente cliente = new Cliente(runCliente, nombreCliente, apellidoCliente, aniosCliente); //Creo un nuevo objeto Cliente cada vez que entro a este metodo

		if(listaClientes!=null) {
			listaClientes.add(cliente);
			System.out.println("Cliente agregado correctamente");
		}else {
			System.out.println("No pudo agregarse elemento a la lista debido a que esta no existe");
		}
		Utilidad.EsperaYLimpieza();
	}

	public void editarCliente (String runCliente, String nombreCliente, String apellidoCliente, String aniosCliente, Cliente cliente) {

		Scanner scanner = new Scanner(System.in);
		
		boolean continuar = false; //Bucle para editar datos, este sera mi confirmador si salgo de editar cliente o no
		
		System.out.println("Se procederan a editar los datos de " + nombreCliente +" "+ apellidoCliente + " cliente por " + aniosCliente + " a�os " + "de RUN " + runCliente);
		Utilidad.espera();
		do {
			Utilidad.limpiar();
			System.out.println("1.- El RUN del cliente es: " + cliente.getRunCliente());
			System.out.println("2.- El nombre del cliente es: " + cliente.getNombreCliente());
			System.out.println("3.- El apellido del cliente es: " + cliente.getApellidoCliente());
			System.out.println("4.- La edad del cliente en nuestra tienda es de : " + cliente.getAniosCliente() + " a�os");
			System.out.println(); //Le muestro a usuario los datos actuales de cliente, estos seran actualizados cada vez que los cambie
			System.out.println("Elija que dato editar del cliente, o ingrese 5 para salir de menu editar clienter");
			String opcion2 = scanner.nextLine();
			switch (opcion2) {
			case "1":
				System.out.println("Ingrese nuevo run del cliente: ");
				cliente.setRunCliente(scanner.nextLine());
				System.out.println("Cliente fue editado con exito.");
				Utilidad.espera();
				break;
			case "2":
				System.out.println("Ingrese nuevo nombre del cliente: ");
				cliente.setNombreCliente(scanner.nextLine());
				System.out.println("Cliente fue editado con exito.");
				Utilidad.espera();
				break;
			case "3":
				System.out.println("Ingrese nuevo apellido del cliente: ");
				cliente.setApellidoCliente(scanner.nextLine());
				System.out.println("Cliente fue editado con exito.");
				Utilidad.espera();
				break;
			case "4":
				System.out.println("Ingrese nuevos a�os que lleva el cliente: ");
				cliente.setAniosCliente(scanner.nextLine());
				System.out.println("Cliente fue editado con exito.");
				Utilidad.espera();
				break;
			case "5":
				System.out.println("Saliendo de editar cliente");
				Utilidad.espera();
				continuar = true; //Si la persona ingresa a 5, saldra del menu definitivamente y volvera al menu principal
				break;
			default:
				System.out.println("Opcion erronea, favor intentar denuevo");
				Utilidad.espera();
				break;
			}
		} while (!continuar);
		Utilidad.EsperaYLimpieza();
	}

	/**
	 * @return the listaClientes
	 */
	public List<Cliente> getListaClientes() {
		return listaClientes;
	}

	/**
	 * @param listaClientes the listaClientes to set
	 */
	public void setListaClientes(List<Cliente> listaClientes) {
		this.listaClientes = listaClientes;
	}



}
