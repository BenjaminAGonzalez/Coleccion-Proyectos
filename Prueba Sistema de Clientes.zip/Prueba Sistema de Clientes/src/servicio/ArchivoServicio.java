/**
 * 
 */
package servicio;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import modelo.Cliente;

/**
 * @author Benja
 *
 */
public class ArchivoServicio extends Exportador {
	
	Scanner scanner = new Scanner(System.in);
	
	public List<Cliente> cargarDatos(String fileName) { //Mi metodo retornara una lista que contiene objetos Cliente
		
		List<Cliente> listaClientes = new ArrayList<Cliente>(); //Creo una nueva lista no asociada con la de sistemas, esta lista sera llenada con lo que se encuentra en DBClientes.csv
		String ruta = scanner.nextLine();
		String archivo = ruta + "/" + fileName;
		
		File crearArchivo = new File(archivo);
		try {
		if(!crearArchivo.isFile()) { //Si la ruta ingresada por el usuario no es un archivo, no ingreso al metodo
			System.out.println("El archivo que esta intentando abrir no existe o no se encuentra en la ruta especificada");
		}else {
			
			FileReader lector = new FileReader (crearArchivo);
			BufferedReader lectorB = new BufferedReader (lector);
			
			String data = lectorB.readLine();
			
			while(data!=null) {
				
				Cliente cliente = new Cliente(); //Cada vez que entro a este bucle, creo una nueva isntancia de cliente con nuevos datos
				String[] datos = data.split(",",5); //Separo cada dato dentro de DBClientes.csv en un array, cada dato es separado cuando encuentra una coma y tiene un limite de 4 valores
				
				cliente.setRunCliente(datos[0]);
				cliente.setNombreCliente(datos[1]);
				cliente.setApellidoCliente(datos[2]);
				cliente.setAniosCliente(datos[3]); //Cada dato separado es asignado en este orden: rut, nombre, apellido, anios
				
				listaClientes.add(cliente); //Los cuales son agregados a la lista temporal
				data = lectorB.readLine();
			}
			lectorB.close();
		}
		}catch(Exception error) {
			System.out.println("Se ha encontrado un error inesperado al intentar leer el archivo, error: " + error.getMessage());
		}
		return listaClientes;
	}

	@Override
	public void exportar(String fileName, List<Cliente> listaClientes) {
		
		Exportador exportador = new ExportadorCsv();
		Exportador exportador2 = new ExportadorTxt();
		exportador.exportar(fileName, listaClientes);
		exportador2.exportar(fileName, listaClientes);

	}

}
