/**
 * 
 */
package servicio;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.List;
import java.util.Scanner;

import modelo.Cliente;

/**
 * @author Benja
 *
 */
public class ExportadorTxt extends Exportador {

	Scanner scanner = new Scanner(System.in);
	@Override
	public void exportar(String fileName, List<Cliente> listaClientes) {

		if(listaClientes.size()==0) {
			System.out.println("La lista se encuentra vacia, por favor, ingrese clientes a la lista");
		}
		else {
			String separador =  ",";
			System.out.println("Ingrese la ruta donde se exportara el archivo .txt, si este ya existe, se sobreescribira");
			String ruta = scanner.nextLine();
			String archivo = ruta + "/" + fileName;

			File crearArchivo = new File(archivo);
			try {
				
				if(crearArchivo.exists()) {
					crearArchivo.delete();
				}
				FileWriter escritor = new FileWriter (crearArchivo);
				BufferedWriter escritorb = new BufferedWriter (escritor);

				for(Cliente cliente: listaClientes) {
					escritorb.append(cliente.getRunCliente()).append(separador).append(cliente.getNombreCliente()).append(separador).append(cliente.getApellidoCliente())
					.append(separador).append(cliente.getAniosCliente());
					escritorb.newLine();
				}
				escritorb.close();
				System.out.println("Datos correctamente exportados a .txt");
			}catch(Exception error) {
				System.out.println("Hubo un error en la exportacion de datos. Favor confirmar la ruta o nombre de archivo ingresados. Mensaje de error: " + error.getMessage());
			}
		}
	}

}
