package vista;

import java.util.List;
import java.util.Scanner;

import modelo.Cliente;
import servicio.ArchivoServicio;
import servicio.ClienteServicio;
import servicio.ExportadorCsv;
import servicio.ExportadorTxt;
import utilidades.Utilidad;

public class Menu {

	ClienteServicio clienteServicio = new ClienteServicio();
	ArchivoServicio archivoServicio = new ArchivoServicio();
	ExportadorCsv exportadorCsv = new ExportadorCsv();
	ExportadorTxt exportarTxt = new ExportadorTxt();
	Scanner scanner = new Scanner(System.in);
	String filename = "Clientes";
	String filename1 = "DBClientes.csv"; //Llamo a las variables que usare, importando las apropiadas clases de cada una

	public void iniciarMenu() {

		boolean continuar = false; //boolean para crear un bucle infinito

		do {
			System.out.println("Opcion 1: Listar Clientes");
			System.out.println("Opcion 2: Agregar Cliente");
			System.out.println("Opcion 3: Editar cliente");
			System.out.println("Opcion 4: Cargar datos");
			System.out.println("Opcion 5: Exportar datos");
			System.out.println("Opcion 6: Salir");
			Utilidad.espera();
			System.out.println("Ingrese una opcion: ");
			String opcion = scanner.nextLine(); //Menu que es mostrado 1 vez al cliente y despues no se le permite salir a menos que ingrese a la opcion salir

			switch(opcion) { //Switch, el cual entrara a cada metodo dependiendo de que opcion ingrese
			case "1": //Utilizamos string 1, 2, etc para abarcar mas posibilidades de error
				listarCliente();
				break;
			case "2":
				agregarCliente();
				break;
			case "3":
				editarCliente();
				break;
			case "4":
				importarDatos();
				break;
			case "5":
				exportarDatos();
				break;
			case "6":
				terminarPrograma();
			default: //Default abarcara cualquier opcion que no sea correcta
				System.out.println("Opcion no valida");
			}
		}while(!continuar); //Bucle infinito para no salir del menu
	}

	private void listarCliente() {
		System.out.println("Usted eligio listar cliente");
		Utilidad.espera();
		clienteServicio.listarClientes();
	}
	private void agregarCliente() {
		System.out.println("Usted eligio agregar cliente");
		Utilidad.espera();
		System.out.println("Ingrese RUN del cliente");
		String run = scanner.nextLine();
		System.out.println("Ingrese nombre del cliente");
		String nombre = scanner.nextLine();
		System.out.println("Ingrese apellido del cliente");
		String apellido = scanner.nextLine();
		System.out.println("Ingrese a�os de permanencia del cliente");
		String anio = scanner.nextLine();
		clienteServicio.agregarCliente(run, nombre, apellido, anio);

	}
	private void editarCliente() {	

		List<Cliente> listaClientes = clienteServicio.getListaClientes();
		System.out.println("Usted eligio editar cliente");
		Utilidad.espera();
		System.out.println("Ingrese RUN del cliente a editar");
		String erun = scanner.nextLine();
		int confirmar = 0;
		if(listaClientes.size()==0) {
			System.out.println("La lista se encuentra actualmente vacia, favor agregue clientes a la lista");
		}
		else {
			for(Cliente cliente: listaClientes) { //Busco en la lista de clientes el cliente que tenga el mismo run que ingresa el usuario
				if(cliente.getRunCliente().equals(erun)) {
					String rut = cliente.getRunCliente();
					String nombre = cliente.getNombreCliente();
					String apellido = cliente.getApellidoCliente();
					String anios = cliente.getAniosCliente();
					clienteServicio.editarCliente(rut, nombre, apellido, anios, cliente);
					confirmar++;  //Si hay al menos 1 run que concuerda, aumento este numero en 1
				}
			}if(confirmar==0){ //Si confirmar no aumento de valor, quiere decir que no encontro el run, y por lo tanto, no existe en la lista
				System.out.println("No se encontro el rut especificado en la lista de clientes, por favor ingrese un RUN valido");
			}
		}
	}
	private void importarDatos() {
		System.out.println("Usted eligio importar datos");
		System.out.println("Ingrese la ruta donde se encuentre DBClientes.csv");

		List<Cliente> listaClientes = clienteServicio.getListaClientes(); //Lista que es traida desde sistema, no importa si no contiene datos, ya que le importaremos datos
		List<Cliente> listaImportada = archivoServicio.cargarDatos(filename1); //Lista que es traida desde el metodo cargarDatos
		
		if(listaImportada.size()!=0) { //Si se encontraron datos en DBClientes, seran agregados, si no fueron encontrados, estos mensajes no se mostraran
		listaClientes.addAll(listaImportada); //Agrego a listaClientes todos los datos de listaImportada, las cuales provienen de DBClientes.csv
		System.out.println("Los datos han sido agregados a la lista correctamente");
		Utilidad.espera();
		System.out.println("Porfavor confirme los datos en Listar clientes o Exportar clientes");
		}
		Utilidad.EsperaYLimpieza();
	}
	private void exportarDatos() {
		System.out.println("Usted eligio exportar datos");
		System.out.println("Seleccione en que formato va a exportar");
		System.out.println("1.-Formato .csv");
		System.out.println("2.-Formato .txt");
		Utilidad.espera();
		System.out.println("Ingrese opcion");

		List<Cliente> listaClientes = clienteServicio.getListaClientes(); //Cargo la lista que ya esta formada en sistema
		String opcion = scanner.nextLine();

		switch(opcion) {

		case "1":
			exportadorCsv.exportar(filename + ".csv", listaClientes); //Exporto como csv
			break;
		case "2":
			exportarTxt.exportar(filename + ".txt", listaClientes); //Exporto como txt
			break;
		default:
			System.out.println("Numero de opcion ingresado erroneamente. Por favor, intente denuevo");
		}
		Utilidad.EsperaYLimpieza();
	}
	private void terminarPrograma() {

		System.out.println("Usted eligio: Salir\n");
		Utilidad.espera();
		System.out.println("El programa se cerrara, hasta pronto");
		Utilidad.EsperaYLimpieza();
		System.exit(0);
	}


}
