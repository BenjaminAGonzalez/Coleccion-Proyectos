
var partidas = parseInt(prompt("Por favor ingrese la cantidad de partidas que desea jugar"));

inicio(partidas);

function inicio(cantidad)   {
    if(cantidad>=1){
        cachipun(cantidad);
    }else{
        alert("Usted ingreso un valor erroneo, favor intente denuevo.");
        return false;
    }
}

function cachipun(partida){
    var cont1 = 0;
    var cont2 = 0;
    for(var i=0; i<partida; i++){
        var jugadaP = eleccion();
        var jugadaC = computadora();
        var puntaje = resolucion(jugadaP, jugadaC);
        if(puntaje===0){
            cont1++;
        }else if (puntaje===1){
            cont2++;
        }
    }   alert("Puntaje final: Jugador --> " + cont2 + " Computadora --> " + cont1);
    if(cont1 > cont2){
        alert("La computadora ha ganado en partidas totales!");
    }
    else if(cont2 > cont1){
        alert("Has ganado en partidas totales! Bien hecho!");
    }
    else{
        alert("Hubo un gran empate!");
    }
}

function eleccion(){
    var mark = false;
    do{
        let mano = parseInt(prompt("Elija 1 para piedra, 2 para papel, o 3 para tijera"));
        switch(mano){
            case 1:
                var decision = mano;
                mark=true;
                break;
            case 2:
                var decision = mano;
                mark=true;
                break;
            case 3:
                var decision = mano;
                mark=true;
                break;
            default:
                alert("Por favor elija una opcion correcta");
                break;
        }
    }while(!mark);
    return decision;
}

function computadora(){
    alert("La computadora esta jugando...");
    var robot = Math.floor(Math.random() *3) +1;
        switch(robot){
            case 1:
                alert("La computadora eligio piedra!");
                break;
            case 2:
                alert("La computadora eligio papel!");
                break;
            case 3:
                alert("La computadora eligio tijera!");
                break;
        }
    return robot;
}

function resolucion(player, computer){
    let score = 0;
    if(player === computer){
        alert("Se ha generado un empate!");
        score = 2;
        return score;
    }
    else if(player===1 && computer===2){
        alert("La computadora ha ganado, intentalo denuevo!");
        return score;
    }
    else if(player===1 && computer===3){
        alert("Has ganado! Felicitaciones!");
        score = 1;
        return score;
    }
    else if(player===2 && computer===1){
        alert("Has ganado! Felicitaciones!");
        score = 1;
        return score;
    }
    else if(player===2 && computer===3){
        alert("La computadora ha ganado, intentalo denuevo!");
        return score;
    }
    else if(player===3 && computer===1){
        alert("La computadora ha ganado, intentalo denuevo!");
        return score;
    }
    else if(player===3 && computer===2){
        alert("Has ganado! Felicitaciones!");
        score = 1;
        return score;
    }
}



