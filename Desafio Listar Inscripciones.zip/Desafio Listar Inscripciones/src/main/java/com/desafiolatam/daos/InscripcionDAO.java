package com.desafiolatam.daos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.desafiolatam.entidades.InscripcionDTO;

public class InscripcionDAO {
	public int insertarInscripcion(InscripcionDTO dto) throws SQLException, ClassNotFoundException {
		int max = 0;
		//Query para obtener una secuencia y asignar un id. La funcion MAX solo obtiene el valor de id_inscripcion
		//y le suma 1, con eso hacemos el incremento
		String consultaProximoId = " SELECT MAX(id_inscripcion)+1 FROM inscripcion";
		//Query que insertara el valor
		String insertarInscripcion = "INSERT INTO inscripcion (nombre, telefono, id_curso, id_forma_pago) "
				+ "VALUES ("
				+ "'" + dto.getNombre() + "'" + " , "
				+ dto.getCelular() + " , "
				+ "'" + dto.getIdCurso() + "'" + " , "
				+ "'" + dto.getIdFormaDePago() + "'" + ")";
		//conexion a la base de datos y ejecucion de la sentencia
				Class.forName("org.postgresql.Driver");
				Connection conexion = null;
				
				conexion = DriverManager.getConnection("jdbc:postgresql://127.0.0.1:5432/postgres","postgres","cbc5537228");
		try(
				PreparedStatement stmt1 = conexion.prepareStatement(consultaProximoId);
				PreparedStatement stmt2 = conexion.prepareStatement(insertarInscripcion);
		   ){
	
			ResultSet resultado = stmt1.executeQuery();
			if(resultado.next()) {
				max = resultado.getInt(1);
				stmt2.setInt(1, max);
				stmt2.setString(2, dto.getNombre());
				stmt2.setString(3, dto.getCelular());
				stmt2.setInt(4, dto.getIdCurso());
				stmt2.setInt(5, dto.getIdFormaDePago());
				
				if(stmt2.executeUpdate() != 1) {
					throw new RuntimeException("A ocurrido un error inesperado");
				}
			}	
		}catch(Exception ex) {
			ex.printStackTrace();
			throw new RuntimeException("A ocurrido un error inesperado" + ex);
		}
		return max;
	}
	
public List<InscripcionDTO> obtieneInscripciones() throws SQLException, ClassNotFoundException {
		System.out.println("xXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
		//creamos la lista de objetos que devolveran los resultados
		List<InscripcionDTO> inscripciones = new ArrayList<InscripcionDTO>();
		
		//creamos la consulta a la base de datos
		
		
		try {
			
			/*Class.forName("org.postgresql.Driver");
			Connection conexion = null;
			
			String url = "jdbc:postgresql://127.0.0.1:5432/postgres";
			conexion = DriverManager.getConnection(url, "postgres", "cbc5537228");
			
			PreparedStatement stmt = conexion.prepareStatement(insertarInscripcion);
			stmt.executeUpdate();*/
			
			
			String consultaSql = "select id_curso, nombre, telefono, id_forma_pago from inscripcion";
			
			//conexion a la base de datos y ejecucion de la sentencia
			Class.forName("org.postgresql.Driver");
			Connection conexion = null;
			String url = "jdbc:postgresql://127.0.0.1:5432/postgres";
			conexion = DriverManager.getConnection(url, "postgres", "cbc5537228");
			
			PreparedStatement stmt = conexion.prepareStatement(consultaSql);
			
			ResultSet resultado = stmt.executeQuery();
			while(resultado.next()) {
				System.out.println("xXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
				InscripcionDTO inscripcion = new InscripcionDTO();
				inscripcion.setIdCurso(resultado.getInt("id_curso"));
				inscripcion.setNombre(resultado.getString("nombre"));
				inscripcion.setCelular(resultado.getString("telefono"));
				inscripcion.setIdFormaDePago(resultado.getInt("id_forma_pago"));
				inscripciones.add(inscripcion);
			}	
			System.out.println("xXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"+ inscripciones);
			
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return inscripciones;
	}
	
	
}
