package com.desafiolatam.facade;

import java.sql.SQLException;
import java.util.List;

import com.desafiolatam.daos.CursoDao;
import com.desafiolatam.daos.FormaDePagoDAO;
import com.desafiolatam.daos.InscripcionDAO;
import com.desafiolatam.entidades.CursoDTO;
import com.desafiolatam.entidades.FormaDePagoDTO;
import com.desafiolatam.entidades.InscripcionDTO;

public class Facade {
	
	public int registrarInscripcion(InscripcionDTO dto) throws SQLException, ClassNotFoundException {
		InscripcionDAO inscripcionDao = new InscripcionDAO();
		return inscripcionDao.insertarInscripcion(dto);
	}
	
	public List<CursoDTO> obtenerCursos() throws SQLException, ClassNotFoundException{
		CursoDao daoCurso = new CursoDao();
		return daoCurso.obtieneCursos();
	}
	
	public List<FormaDePagoDTO> obtenerFormasDePago() throws SQLException, ClassNotFoundException{
		FormaDePagoDAO daoPago = new FormaDePagoDAO();
		return daoPago.obtieneFormasDePago();
	}
	
	//Implementar metodo obtieneInscripciones, llama a metodo de clase InscripcionDAO de nombre obtieneInscripciones
	//FAVOR HACER CORRER SERVLET PARA QUE FUNCIONE, MUCHAS GRACIAS
	
	public List<InscripcionDTO> obtieneInscripciones() throws SQLException, ClassNotFoundException{
		InscripcionDAO daoInscripcion = new InscripcionDAO();
		return daoInscripcion.obtieneInscripciones();
	}
}


