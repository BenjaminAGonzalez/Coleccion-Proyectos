--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1
-- Dumped by pg_dump version 14.1

-- Started on 2022-03-23 10:56:20

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 217 (class 1259 OID 25385)
-- Name: curso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.curso (
    id_curso character varying(50) NOT NULL,
    descripcion character varying(100),
    precio numeric(22,0)
);


ALTER TABLE public.curso OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 25390)
-- Name: forma_pago; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.forma_pago (
    id_forma_pago character varying(50),
    descripcion character varying(100),
    recargo character varying(100)
);


ALTER TABLE public.forma_pago OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 25429)
-- Name: inscripcion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inscripcion (
    codigo integer NOT NULL,
    nombre character varying(100),
    telefono numeric(22,0),
    id_curso character varying(50),
    id_forma_pago character varying(50)
);


ALTER TABLE public.inscripcion OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 25428)
-- Name: inscripcion_codigo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inscripcion_codigo_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.inscripcion_codigo_seq OWNER TO postgres;

--
-- TOC entry 3346 (class 0 OID 0)
-- Dependencies: 220
-- Name: inscripcion_codigo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inscripcion_codigo_seq OWNED BY public.inscripcion.codigo;


--
-- TOC entry 3192 (class 2604 OID 25432)
-- Name: inscripcion codigo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inscripcion ALTER COLUMN codigo SET DEFAULT nextval('public.inscripcion_codigo_seq'::regclass);


--
-- TOC entry 3337 (class 0 OID 25385)
-- Dependencies: 217
-- Data for Name: curso; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.curso (id_curso, descripcion, precio) FROM stdin;
1	Java Enterprice Edition	800
2	Java Standar Edition	600
3	JavaScript ECMA 6	500
\.


--
-- TOC entry 3338 (class 0 OID 25390)
-- Dependencies: 218
-- Data for Name: forma_pago; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.forma_pago (id_forma_pago, descripcion, recargo) FROM stdin;
1598	Tarjeta Credito	10%
1547	Tarjeta Debito	15%
3578	Efectivo	5%
\.


--
-- TOC entry 3340 (class 0 OID 25429)
-- Dependencies: 221
-- Data for Name: inscripcion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inscripcion (codigo, nombre, telefono, id_curso, id_forma_pago) FROM stdin;
3	Benjamin	55555555	3	1598
4	Benjamin	55555555	3	1598
5	Benjamin	55555555	3	1598
6	Benjamin	55555555	3	1598
7	Benjamin	55555555	3	1598
\.


--
-- TOC entry 3347 (class 0 OID 0)
-- Dependencies: 220
-- Name: inscripcion_codigo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inscripcion_codigo_seq', 7, true);


--
-- TOC entry 3194 (class 2606 OID 25389)
-- Name: curso curso_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.curso
    ADD CONSTRAINT curso_pkey PRIMARY KEY (id_curso);


--
-- TOC entry 3196 (class 2606 OID 25434)
-- Name: inscripcion inscripcion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inscripcion
    ADD CONSTRAINT inscripcion_pkey PRIMARY KEY (codigo);


--
-- TOC entry 3197 (class 2606 OID 25435)
-- Name: inscripcion inscripcion_id_curso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inscripcion
    ADD CONSTRAINT inscripcion_id_curso_fkey FOREIGN KEY (id_curso) REFERENCES public.curso(id_curso);


-- Completed on 2022-03-23 10:56:20

--
-- PostgreSQL database dump complete
--

