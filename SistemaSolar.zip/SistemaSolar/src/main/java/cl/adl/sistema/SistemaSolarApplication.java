package cl.adl.sistema;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaSolarApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaSolarApplication.class, args);
	}

}
// Comentario de prueba
// Otro comentario