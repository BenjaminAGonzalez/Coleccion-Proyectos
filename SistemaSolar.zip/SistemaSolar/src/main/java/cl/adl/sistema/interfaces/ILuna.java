package cl.adl.sistema.interfaces;

import java.util.ArrayList;

import cl.adl.sistema.dto.Luna;

public interface ILuna {
	
	public ArrayList<Luna> construirLuna(String nombre, String diametro, String tiempoOrbita);

}
