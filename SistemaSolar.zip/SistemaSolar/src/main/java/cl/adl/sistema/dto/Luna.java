package cl.adl.sistema.dto;

public class Luna {
	
	private String nombre;
	private String diametro;
	private String tiempoOrbita;
	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * @return the diametro
	 */
	public String getDiametro() {
		return diametro;
	}
	/**
	 * @return the tiempoOrbita
	 */
	public String getTiempoOrbita() {
		return tiempoOrbita;
	}
	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * @param diametro the diametro to set
	 */
	public void setDiametro(String diametro) {
		this.diametro = diametro;
	}
	/**
	 * @param tiempoOrbita the tiempoOrbita to set
	 */
	public void setTiempoOrbita(String tiempoOrbita) {
		this.tiempoOrbita = tiempoOrbita;
	}
	@Override
	public String toString() {
		return "Luna [nombre=" + nombre + ", diametro=" + diametro + ", tiempoOrbita=" + tiempoOrbita + "]";
	}
	
	

}
