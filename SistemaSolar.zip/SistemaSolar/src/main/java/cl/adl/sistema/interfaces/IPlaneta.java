package cl.adl.sistema.interfaces;

import java.util.ArrayList;

import cl.adl.sistema.dto.Luna;
import cl.adl.sistema.dto.Planeta;

public interface IPlaneta {
	
	public Planeta construirPlaneta(String nombre, String tamanio, String distanciaSol, String distanciaLuna, ArrayList<Luna> luna);

}
