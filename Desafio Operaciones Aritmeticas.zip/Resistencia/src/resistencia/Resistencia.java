package resistencia;

import java.util.Scanner;


public class Resistencia {

	public static void main(String[] args) {
		
		double R1 = 0.0;
		double R2 = 0.0;
		double R3 = 0.0;
		Scanner sc = new Scanner(System.in);
		do{
			System.out.printf("Ingrese resistencia 1: ");
			R1 = sc.nextDouble();
			if(R1 <= 0) {
			System.out.println("Dato inv�lido");
			}
			}while(R1 <= 0);
		do{
			System.out.printf("Ingrese resistencia 2: ");
			R2 = sc.nextDouble();
			if(R2 <= 0) {
			System.out.println("Dato inv�lido");
			}
			}while(R2 <= 0);
			
		do{
			System.out.printf("Ingrese resistencia 3: ");
			R3 = sc.nextDouble();
			if(R3 <= 0) {
			System.out.println("Dato inv�lido");
			}
			}while(R3 <= 0);
		
		double resistenciat = 1/((1/R1) + (1/R2) + (1/R3));
		
		System.out.println("La resistencia total es de: " + resistenciat);
	}
}
