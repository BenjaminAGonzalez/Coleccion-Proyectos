package desafios;

import java.util.Scanner;

public class SumaImparLimite {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.printf("Ingrese limite inferior : ");

		int min = sc.nextInt();

		System.out.printf("Ingrese limite superior : ");

		int impar = 0;

		int max= sc.nextInt();

		int contador;
		
		sc.close();

		for(contador = min; min <= max; contador++) {
			if (contador%2 != 0) {
				impar = impar + contador;
				min++;
			}
			else {
				min++;
			}
			
		}	
		System.out.println(impar);
		
	}
}


