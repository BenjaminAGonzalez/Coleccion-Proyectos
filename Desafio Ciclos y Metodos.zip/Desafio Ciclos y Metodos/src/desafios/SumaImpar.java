package desafios;

import java.util.Scanner;

public class SumaImpar {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.printf("Ingrese hasta que numero los impares se sumaran : ");

		int suma = 0;

		int cantidad = sc.nextInt();

		for(int contador = 0; contador<=cantidad; contador++) {
			if(contador%2==1) {
				suma = contador + suma;
			}
		}
		System.out.println(suma);
		sc.close();
	}
}
