package desafios;

public class CambiarWhile {

	public static void main(String[] args) {

		int i = 0;
		do {
			i+=1;
			System.out.printf("Iteracion %d\n", i);
		}
		while(i<50);
	}

}
