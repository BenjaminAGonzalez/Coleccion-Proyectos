package desafios;

import java.util.Scanner;

public class SoloPares2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.printf("Ingrese cuantos pares se mostraran : ");

		int cantidad = sc.nextInt();

		int pares = 1;

		for(int contador = 1; pares <= cantidad; contador++) {
			if(contador%2==0){
				System.out.println(contador);
				pares++;
			}
		}
		sc.close();

	}


}


