package desafios;

import java.util.Scanner;

public class Fibonacci {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

		System.out.printf("Ingrese cuantos numeros de Fibbonacci desea: ");

		int limite = sc.nextInt();

		int fib = 0;

		int fn = 0;

		int fx = 1;

		int contador;

		sc.close();

		System.out.println(fn);
		System.out.println(fx);

		for(contador = 2; contador <= limite; contador++) {	

			fib = fn + fx;
			System.out.println(fib);
			fn = fx;
			fx = fib;

		}

	}

}


