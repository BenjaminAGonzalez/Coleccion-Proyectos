
var radiologia = [
    {
        hora: '11:00',
        medico: 'IGNACIO SCHULZ',
        paciente: 'FRANCISCA ROJAS',
        rutP: '9878782-1',
        prevision: 'FONASA'
    },
    {
        hora: '11:30',
        medico: 'FEDERICO SUBERCASEAUX',
        paciente: 'PAMELA ESTRADA',
        rutP: '15345241-3',
        prevision: 'ISAPRE'
    },
    {
        hora: '15:00',
        medico: 'FERNANDO WURTHZ',
        paciente: 'ARMANDO LUNA',
        rutP: '16445345-9',
        prevision: 'ISAPRE'
    },
    {
        hora: '15:30',
        medico: 'ANA MARIA GODOY',
        paciente: 'MANUEL GODOY',
        rutP: '17666419-0',
        prevision: 'FONASA',
    },
    {
        hora: '16:00',
        medico: 'PATRICIA SUAZO',
        paciente: 'RAMON ULLOA',
        rutP: '14989389-K',
        prevision: 'FONASA',
    },
]

var traumatologia = [

    { hora: "08:00", especialista: "MARIA PAZ ALTUZARRA", paciente: "PAULA SANCHEZ", rut: "15554774-5", prevision: "FONASA" },
    { hora: "10:00", especialista: "RAUL ARAYA", paciente: "ANGÉLICA NAVAS", rut: "15444147-9", prevision: "ISAPRE" },

    { hora: "10:30", especialista: "MARIA ARRIAGADA", paciente: "ANA KLAPP", rut: "17879423-9", prevision: "ISAPRE" },

    { hora: "11:00", especialista: "ALEJANDRO BADILLA", paciente: "FELIPE MARDONES", rut: "1547423-6", prevision: "ISAPRE" },
    { hora: "11:30", especialista: "CECILIA BUDNIK", paciente: "DIEGO MARRE", rut: "16554741-K", prevision: "FONASA" },

    { hora: "12:00", especialista: "ARTURO CAVAGNARO", paciente: "CECILIA MENDEZ", rut: "9747535-8", prevision: "ISAPRE" },

    { hora: "12:30", especialista: "ANDRES KANACRI", paciente: "MARCIAL SUAZO", rut: "11254785-5", prevision: "ISAPRE" },


]

var dental = [{
    hora: '08:30',
    especialista: 'Andrea Zuñiga',
    paciente: 'Marcela Retamal',
    rut: '11123425-6',
    prevision: 'ISAPRE'
},
{
    hora: '11:00', especialista: 'María Pía Zañartu', paciente: 'Angel Muñoz', rut: '9878789-2', prevision: 'ISAPRE'
},
{
    hora: '11:30', especialista: 'Scarlett Witting', paciente: 'Mario Kast', rut: '7998789-5', prevision: 'FONASA'
},
{
    hora: '13:00', especialista: 'Francisco Von Teuber', paciente: 'Karin Fernández', rut: '18887662-k', prevision: 'FONASA'
},
{
    hora: '13:30', especialista: 'Eduardo Viñuela', paciente: 'Hugo Sanchez', rut: '17665461-4', prevision: 'FONASA'
},
{
    hora: '14:00', especialista: 'Raquel Villaseca', paciente: 'Ana Sepúlveda', rut: '14441281-0', prevision: 'ISAPRE'
}
];


// EJERCICIO PARTE 2 USO DE METODOS EN ARRAYS
//EJERCICIO 1 AGREGAR NUEVOS DATOS A TRAUMATOLOGIA  
traumatologia.push(
    {
        hora: '09:00',
        especialista: 'RENE POBLETE',
        paciente: 'ANA GELLONA',
        rut: '13123329-7',
        prevision: 'ISAPRE'
    },
    {
        hora: '09:30',
        especialista: 'MARIA SOLAR',
        paciente: 'RAMIRO ANDRADE',
        rut: '12221451-K',
        prevision: 'FONASA'
    },
    {
        hora: '10:00',
        especialista: 'RAUL LOYOLA',
        paciente: 'CARMEN ISLA',
        rut: '10112348-3',
        prevision: 'ISAPRE'
    },
    {
        hora: '10:30',
        especialista: 'ANTONIO LARENAS',
        paciente: 'PABLO LOAYZA',
        rut: '13453234-1',
        prevision: 'ISAPRE',
    },
    {
        hora: '12:00',
        especialista: 'MATIAS ARAVENA',
        paciente: 'SUSANA POBLETE',
        rut: '14345656-6',
        prevision: 'FONASA',
    },)

//EJERCICIO 2 ELIMINAR PRIMER Y ULTIMO DATO DE RADIOLOGIA

radiologia.shift();
radiologia.pop();

//EJERCICIO 3 IMPRIMIR CONSULTAS DENTAL

document.write('Consultas dentales');

for(var i = 0; i<dental.length; i++){

let listaDental = [dental[i].hora , dental[i].especialista, dental[i].paciente, dental[i].rut, dental[i].prevision ]

    document.write(listaDental.join(' - '));
    document.write('<br>');

}

//EJERCICIO 4 IMPRIMIR TODOS LOS PACIENTES

document.write('Lista pacientes <br>');

var pacientes = [];

for(var i = 0; i<radiologia.length; i++){
    pacientes.push(radiologia[i].paciente);
}

for(var i = 0; i<traumatologia.length; i++){
    pacientes.push(traumatologia[i].paciente);
}
for(var i = 0; i<dental.length; i++){
    pacientes.push(dental[i].paciente);
}

document.write(pacientes.join('<br>'));

//EJERCICIO 5 FILTRAR ISAPRES

document.write('<br> PACIENTES DENTALES QUE TIENEN ISAPRE <br>')

var soloIsapre = dental.filter(
    function(pacienteD){
    return pacienteD.prevision == 'ISAPRE';
})

for(var i = 0; i<soloIsapre.length ; i++){
    document.write(soloIsapre[i].paciente + ' - ' + soloIsapre[i].prevision);
    document.write('<br>');
}

//EJERCICIO 6 FILTRAR FONASA

document.write('<br> PACIENTES TRAUMATOLOGIA QUE TIENEN FONASA <br>')

var soloFonasa = traumatologia.filter(
    function(pacienteT){
    return pacienteT.prevision == 'FONASA';
})

for(var i = 0; i<soloFonasa.length ; i++){
    document.write(soloFonasa[i].paciente + ' - ' + soloFonasa[i].prevision);
    document.write('<br>');
}


document.getElementById("horasRadio").innerHTML = 'Radiologia --> Primera atencion: ' + radiologia[0].paciente + ' - ' + radiologia[0].prevision + ' | ' + 'Ultima atencion: ' + radiologia[radiologia.length - 1].paciente + ' - ' + radiologia[radiologia.length - 1].prevision;

document.write('<br>')

document.getElementById("horasTrauma").innerHTML = ('Traumatologia --> Primera atencion: ' + traumatologia[0].paciente + ' - ' + traumatologia[0].prevision + ' | ' + 'Ultima atencion: ' + traumatologia[traumatologia.length - 1].paciente + ' - ' + traumatologia[traumatologia.length - 1].prevision)

document.write('<br>')

document.getElementById("horasDental").innerHTML = ('Dental --> Primera atencion: ' + dental[0].paciente + ' - ' + dental[0].prevision + ' | ' + 'Ultima atencion: ' + dental[dental.length - 1].paciente + ' - ' + dental[dental.length - 1].prevision)

var texto = "<tr><th>Hora</th><th>Medico</th><th>Paciente</th><th>Rut</th><th>Prevision</th></tr>";

for (var i = 0; i < radiologia.length; i++) {

    texto += "<tr>" +
        "<td>" + radiologia[i].hora + "</td>" +
        "<td>" + radiologia[i].medico + "</td>" +
        "<td>" + radiologia[i].paciente + "</td>" +
        "<td>" + radiologia[i].rutP + "</td>" +
        "<td>" + radiologia[i].prevision + "</td>" +
        "</tr>";

}

var texto2 = "<tr><th>Hora</th><th>Medico</th><th>Paciente</th><th>Rut</th><th>Prevision</th></tr>";

for (var i = 0; i < traumatologia.length; i++) {

    texto2 += "<tr>" +
        "<td>" + traumatologia[i].hora + "</td>" +
        "<td>" + traumatologia[i].especialista + "</td>" +
        "<td>" + traumatologia[i].paciente + "</td>" +
        "<td>" + traumatologia[i].rut + "</td>" +
        "<td>" + traumatologia[i].prevision + "</td>" +
        "</tr>";

}

var texto3 = "<tr><th>Hora</th><th>Medico</th><th>Paciente</th><th>Rut</th><th>Prevision</th></tr>";

for (var i = 0; i < dental.length; i++) {

    texto3 += "<tr>" +
        "<td>" + dental[i].hora + "</td>" +
        "<td>" + dental[i].especialista + "</td>" +
        "<td>" + dental[i].paciente + "</td>" +
        "<td>" + dental[i].rut + "</td>" +
        "<td>" + dental[i].prevision + "</td>" +
        "</tr>";

}

document.getElementById("radiologia").innerHTML = texto;
document.getElementById("traumatologia").innerHTML = texto2;
document.getElementById("dental").innerHTML = texto3;




