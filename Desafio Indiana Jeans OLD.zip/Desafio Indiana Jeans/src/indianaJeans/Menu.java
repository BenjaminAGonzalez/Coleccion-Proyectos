/**
 * 
 */
package indianaJeans;

import java.util.List;
import java.util.Scanner;

/**
 * @author Benja
 *
 */
public class Menu {
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		ProductoServicio productoServicio = new ProductoServicio();
		ExportadorTxt exportar = new ExportadorTxt();
		Scanner scanner = new Scanner(System.in);
		boolean check = true;
		
		while(check=true) { //Bucle infinito para menu
			System.out.println("Ingrese un numero para elegir la opcion: ");
			System.out.println("Opcion 1: Listar Producto");
			System.out.println("Opcion 2: Agregar Producto");
			System.out.println("Opcion 3: Exportar datos");
			System.out.println("Opcion 4: Salir");
			String resp = scanner.nextLine();
			if(resp.equals("1")) { //Usamos string para abarcar mas casos excepcionales como el usuario ingresando un string
				System.out.println("Usted eligio: Listar Producto");
				productoServicio.listarProductos();
				check=true; //Como check queda en true, vuelve a menu
			}else if(resp.equals("2")){ //Asi comparamos si el 2 ingresado con un string de 2 para ingresar a opciones
				System.out.println("Usted eligio: Agregar Producto\n");
				System.out.println("Ingresar nombre articulo:");
				String articulo = scanner.nextLine();
				System.out.println("Ingresa codigo:");
				String codigo = scanner.nextLine();
				System.out.println("Ingresa color:");
				String color = scanner.nextLine();
				System.out.println("Ingresa descripcion:");
				String descripcion = scanner.nextLine();
				System.out.println("Ingresa marca:");
				String marca = scanner.nextLine();
				System.out.println("Ingresa precio:");
				String precio = scanner.nextLine();
				System.out.println("Ingresa talla:");
				String talla = scanner.nextLine();
				productoServicio.agregarProductos(articulo, codigo, color, descripcion, marca, precio, talla);
				check = true;
			}else if(resp.equals("3")) {
				System.out.println("Usted eligio: Exportar datos\n");
				List<Producto> listaProductos = productoServicio.getListaProductos();
				System.out.println("Ingrese ruta donde se guardara el archivo");
				String ruta = scanner.nextLine();
				System.out.println("Ingrese nombre del archivo");
				String archivo = scanner.nextLine();
				exportar.exportar(archivo, ruta, listaProductos);
				check = true;
			}else if(resp.equals("4")) {
				System.out.println("Usted eligio: Salir\n");
				System.out.println("El programa se cerrara, hasta pronto");
				Utilidad.EsperaYLimpieza();
				System.exit(0);
			}else {
				System.out.println("Opcion no valida");
			}
		}
		scanner.close();
	}


}
