package Educacion;

/**
 * Este es el objeto Padre del software.
 * @author jonhson
 *
 */


public abstract class SistemaEducativo {
	
	protected String identificador;
	protected String nombre;
	protected String giro;
	
	
	/**
	 * @param identificador
	 * @param nombre
	 * @param giro
	 */
	
	public SistemaEducativo(String identificador, String nombre, String giro) {
		this.identificador = identificador;
		this.nombre = nombre;
		this.giro = giro;
	}
	
	
	/**
	 * @return the identificador
	 */
	public String getIdentificador() {
		return identificador;
	}
	/**
	 * @param identificador the identificador to set
	 */
	public void setIdentificador(String identificador) {
		this.identificador = identificador;
	}
	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * @return the giro
	 */
	public String getGiro() {
		return giro;
	}
	/**
	 * @param giro the giro to set
	 */
	public void setGiro(String giro) {
		this.giro = giro;
	}
	
	
	
	
	
	

}
