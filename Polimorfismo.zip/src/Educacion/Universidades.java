/**
 * 
 */
package Educacion;

/**
 * @author jonhson
 *
 */
public class Universidades extends SistemaEducativo {

	private String sede;

	/**
	 * @param identificador
	 * @param nombre
	 * @param giro
	 * @param sede
	 */
	public Universidades(String identificador, String nombre, String giro, String sede) {
		super(identificador, nombre, giro);
		this.sede = sede;
	}

	/**
	 * @return the sede
	 */
	public String getSede() {
		return sede;
	}

	/**
	 * @param sede the sede to set
	 */
	public void setSede(String sede) {
		this.sede = sede;
	}

	@Override
	public String toString() {
		return "Universidades [sede=" + sede + ", Identificador=" + getIdentificador() + ", Nombre="
				+ getNombre() + ", Giro=" + getGiro() + "]";
	}
	

}
