/**
 * 
 */
package Educacion;

/**
 * @author jonhson
 *
 */
public class Colegio extends SistemaEducativo{
	
	private String direccion;
	private String Comuna;

	/**
	 * @param identificador
	 * @param nombre
	 * @param giro
	 * @param direccion
	 * @param comuna
	 */
	public Colegio(String identificador, String nombre, String giro, String direccion, String comuna) {
		super(identificador, nombre, giro);
		this.direccion = direccion;
		this.Comuna = comuna;
	}

	/**
	 * @return the direccion
	 */
	public String getDireccion() {
		return direccion;
	}

	/**
	 * @param direccion the direccion to set
	 */
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	/**
	 * @return the comuna
	 */
	public String getComuna() {
		return Comuna;
	}

	/**
	 * @param comuna the comuna to set
	 */
	public void setComuna(String comuna) {
		Comuna = comuna;
	}

	@Override
	public String toString() {
		return      "Colegio [direccion=" + direccion + ", Comuna=" + Comuna + ", Identificador=" + getIdentificador()
				+ ", Nombre=" + getNombre() + ", Giro=" + getGiro() + "]";
	}
	
	
}
