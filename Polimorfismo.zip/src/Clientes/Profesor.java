package Clientes;

public class Profesor extends Persona {

	private int sueldo;

	/**
	 * 
	 */
	public Profesor() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param rut
	 * @param nombre
	 * @param apellido
	 */
	public Profesor(String rut, String nombre, String apellido, int sueldo) {
		super(rut, nombre, apellido);
		this.sueldo = sueldo;
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the sueldo
	 */
	public int getSueldo() {
		return sueldo;
	}

	/**
	 * @param sueldo the sueldo to set
	 */
	public void setSueldo(int sueldo) {
		this.sueldo = sueldo;
	}

	@Override
	public String toString() {
		return "Profesor [sueldo=" + sueldo + ", getRut()=" + getRut() + ", getNombre()=" + getNombre()
				+ ", getApellido()=" + getApellido() + "]";
	}

	

	

}
