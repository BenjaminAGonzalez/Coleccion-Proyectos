/**
 * 
 */
package Clientes;

/**
 * @author jonhson
 *
 */
public class Estudiantes extends Persona {
	
	private String Generacion;

	/**
	 * 
	 */
	public Estudiantes() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param rut
	 * @param nombre
	 * @param apellido
	 */
	public Estudiantes(String rut, String nombre, String apellido, String Generacion) {
		super(rut, nombre, apellido);
		this.Generacion = Generacion;
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Estudiantes [Generacion=" + Generacion + ", getRut()=" + getRut() + ", getNombre()=" + getNombre()
				+ ", getApellido()=" + getApellido() + "]";
	}

	/**
	 * @return the generacion
	 */
	public String getGeneracion() {
		return Generacion;
	}

	/**
	 * @param generacion the generacion to set
	 */
	public void setGeneracion(String generacion) {
		Generacion = generacion;
	}


	

}
