/**
 * 
 */
package Clientes;

/**
 * @author jonhson
 *
 */
public abstract class Persona {

	protected String rut;
	protected String nombre;
	protected String Apellido;

	/**
	 * constructor vacio
	 */
	public Persona() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param rut
	 * @param nombre
	 * @param apellido
	 */
	public Persona(String rut, String nombre, String apellido) {
		this.rut = rut;
		this.nombre = nombre;
		Apellido = apellido;
	}

	/**
	 * @return the rut
	 */
	public String getRut() {
		return rut;
	}

	/**
	 * @param rut the rut to set
	 */
	public void setRut(String rut) {
		this.rut = rut;
	}

	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return the apellido
	 */
	public String getApellido() {
		return Apellido;
	}

	/**
	 * @param apellido the apellido to set
	 */
	public void setApellido(String apellido) {
		Apellido = apellido;
	}

	@Override
	public String toString() {
		return "Persona [rut=" + rut + ", nombre=" + nombre + ", Apellido=" + Apellido + "]";
	}
	

}
