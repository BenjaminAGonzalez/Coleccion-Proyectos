package BaseDatos;

import java.util.ArrayList;

import Bootcamp.Curso;
import Clientes.Estudiantes;
import Clientes.Profesor;
import Educacion.Colegio;
import Educacion.Universidades;

public class base_datos {
	
	
	public void Mostrar_Colegios() {
		
		ArrayList<Colegio> coles = new ArrayList<Colegio>();
		
		coles.add(new Colegio("1.234.567-8", "Colegio_Ejemplo", "Educacion","Calle Ejemplo","Comuna Ejemplo"));
		coles.add(new Colegio("1.234.567-9", "Colegio_Ejemplo2 ", "Educacion","Calle Ejemplo 2","Comuna Ejemplo 2"));		
		
		for (Colegio colleges : coles) {
			System.out.println(colleges);
		}		
	}
	
	
	public void Mostrar_Universidades() {
		
		ArrayList<Universidades> uni = new ArrayList<Universidades>();
		
		uni.add(new Universidades("1.234.567-8", "Universidad_Ejemplo", "Educacion Superior", "Puerto Montt"));
		uni.add(new Universidades("1.234.567-9", "Universidad_Ejemplo 2", "Educacion Superior", "Santiago"));
		
		for (Universidades university : uni) {
			System.out.println(university);
		}		
	}

	public void Mostrar_Estudiantes() {
		
		ArrayList<Estudiantes> est = new ArrayList<Estudiantes>();
		
		est.add(new Estudiantes("1.234.567-8", "Estudiante_Ejemplo", "Apellido_Ejemplo", "Escolar"));
		est.add(new Estudiantes("1.234.567-9", "Estudiante_Ejemplo 2", "Apellido_Ejemplo 2", "Universitario"));
		
		for (Estudiantes students : est) {
			System.out.println(students);
		}		
	}
	
	public void Mostrar_Bootcamps() {
		
		Curso fs = Curso.getSingletonInstance("Full Stack Java G1");
		Curso fs2 = Curso.getSingletonInstance("Full Stack Java G2");
        		
	}
	
	public void Mostrar_Profesor() {
		
		ArrayList<Profesor> profe = new ArrayList<Profesor>();
		profe.add(new Profesor("1.234.567-8", "Cristian", "Jonhson", 1000000));
		profe.add(new Profesor("1.234.567-6", "Rodrigo", "Silva", 1000000));
		
		for (Profesor profesor : profe) {
			System.out.println(profesor);
		}
	}
	
	
	
	
}