package Menu;

import java.util.Scanner;

import BaseDatos.base_datos;

/**
 * @author jonhson
 *
 */
public class Menu {
	

	public static void MostrarMenu() {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("");
		System.out.println("Menu "+" \n" +
				" 1. Lista Universidades" +	" \n"	+
				" 2. Lista Estudiantes" +	" \n"	+
				" 3. Lista Colegios" +	" \n" +
				" 4. Lista Bootcamp" +	" \n" +	
				 "5. Lista Profesor" + "\n" );
				
		
		System.out.print("Ingrese una opcion del menu: ");
		
		int opcion = sc.nextInt();
		
		if (opcion == 1) {
			System.out.println("\n");
			base_datos bd = new base_datos();
			System.out.println("======Lista Universidades=======\n");
			bd.Mostrar_Universidades();
			ContinuarMenu();
			
		} else if (opcion == 2) {
			System.out.println("\n");
			base_datos bd = new base_datos();
			System.out.println("======Lista Estudiantes=======\n");
			bd.Mostrar_Estudiantes();
			ContinuarMenu();
			
		} else if (opcion == 3) {
			System.out.println("\n");
			base_datos bd = new base_datos();
			System.out.println("======Lista Colegios=======\n");
			bd.Mostrar_Colegios();
			ContinuarMenu();
			
		}  else if (opcion == 4) {
			System.out.println("\n");
			base_datos bd = new base_datos();
			System.out.println("======Lista Bootcamp=======\n");
			bd.Mostrar_Bootcamps();
			ContinuarMenu();}
		
		  else if (opcion == 5) {
			System.out.println("\n");
			base_datos bd = new base_datos();
			System.out.println("======Lista Profesores=======\n");
			bd.Mostrar_Profesor();
			ContinuarMenu();}
				
		else {
			System.out.println("Opcion invalida, inserte nuevamente");
	}
		sc.close();

}
	
	public static void ContinuarMenu() {
		System.out.println("");
		System.out.println("¿Desea continuar?");

		System.out.println("1. Si" + " \n" + "2. No \n");

		Scanner sc = new Scanner(System.in);

		System.out.print("Ingrese una opcion del menu: ");

		int opcion = sc.nextInt();

		if (opcion == 1) {
			MostrarMenu();
		} else if (opcion == 2) {         
			System.out.println("Hasta Pronto, nos vemos!");
		}
		else {
			System.out.println("Vuelva a escribir una opcion correcta");	
			ContinuarMenu();
		}
		sc.close();
	}
	
	
}