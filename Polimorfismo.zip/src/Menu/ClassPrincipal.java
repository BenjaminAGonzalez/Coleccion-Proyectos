package Menu;



/**
 * Clase Principal
 * @author jonhson
 *
 */
public class ClassPrincipal {

	/**
	 * @param args metodo principal
	 */

	@SuppressWarnings("static-access")
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Menu m = new Menu();
		m.MostrarMenu();

	}
}