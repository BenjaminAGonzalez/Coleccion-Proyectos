/**
 * 
 */
package Bootcamp;

/**
 * @author jonhson
 *
 */
public class Curso {
	
	
	private String nombre;
    private static Curso UnicoCurso;

    // El constructor es privado, no permite que se genere un constructor por defecto.
    private Curso(String nombre) {
        this.nombre = nombre;
        System.out.println("El curso que se cursa es: " + this.nombre);
    }

    public static Curso getSingletonInstance(String nombre) {
        if (UnicoCurso == null){
        	UnicoCurso = new Curso(nombre);
        }
        else{
            System.out.println("No se puede crear el objeto "+ nombre + " porque ya existe un objeto de la clase Curso");
        }
        
        return UnicoCurso;
    }

}
