package Desafio;

import java.io.File;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class ProcesarArchivos {

	public static void main(String[] args) throws IOException {
		
			Scanner sc = new Scanner(System.in);
			String carpeta = "src/directorio";
			String archivo = "src/directorio/fichero.txt";
			System.out.println("Escriba texto a buscar");
			String texto = sc.nextLine();
			crearArchivo(carpeta, archivo);
			System.out.println("cantidad de repeticiones del texto ->"+ buscarTexto(archivo,texto));
			
	}

	public static void crearArchivo (String directorio, String fichero) {
		
		ArrayList<String> lista = new ArrayList<String>();
		lista.add("Perro");
		lista.add("Gato");
		lista.add("Juan");
		lista.add("Daniel");
		lista.add("Juan");
		lista.add("Gato");
		lista.add("Perro");
		lista.add("Camila");
		lista.add("Daniel");
		lista.add("Camila"); 
		
		File crearcarpeta = new File(directorio);
		File creararchivo = new File (fichero);

		if(!crearcarpeta.exists()) {
			try {
				if(crearcarpeta.mkdir()) {
					creararchivo.createNewFile();
					FileWriter escritor = new FileWriter(creararchivo);
					BufferedWriter escritorb = new BufferedWriter(escritor);
					for (Iterator iterator = lista.iterator(); iterator.hasNext();) {
						String elementoAEscribir = (String) iterator.next();
						escritorb.write(elementoAEscribir);
						escritorb.newLine();
					}
					escritorb.close();
					System.out.println("Fichero creado exitosamente");
				}
			}catch (Exception  ex) {
				System.out.println("Error: " + ex.getMessage());
			}
		}else {
			System.out.println("Error al crear directorio");
		}
	}
		
	public static int buscarTexto(String nombreFichero, String texto) throws IOException {

		File archivo = new File (nombreFichero);
		FileReader leerArchivo = new FileReader (nombreFichero);
		BufferedReader BleerArchivo = new BufferedReader (leerArchivo);
		int contador = 0;
		String datosArchivo = BleerArchivo.readLine();

		if(archivo.exists()) {
			while(datosArchivo != null) {
				if(datosArchivo.equals(texto)){
					contador++;
					datosArchivo = BleerArchivo.readLine();
				}else {
					datosArchivo = BleerArchivo.readLine();
				}
			}
			BleerArchivo.close();
		}else {
			System.out.println("El fichero ingresado no existe");
		}
		return contador;
	}

}
