package com.latam.jpacrud.servicio.impl;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.context.annotation.SessionScope;

import com.latam.jpacrud.MiercolesMegaSuperJPAWebExpApplication;
import com.latam.jpacrud.modelo.Usuario;
import com.latam.jpacrud.servicio.SecurityService;

@SessionScope
@Service
public class SecurityServiceImpl implements SecurityService {

	private static final Logger log = LoggerFactory.getLogger(MiercolesMegaSuperJPAWebExpApplication.class);
	Usuario usuarioConectado; 

	
	@Override
	public boolean isLoggedIn() {
		log.info(String.format("Consultando por usuario autenticado (%s)", usuarioConectado));
		return null != this.usuarioConectado;
	}

	@Override
	public Usuario getUsuarioConectado() {
		log.info("Devolviendo al usuario conectado");
		return usuarioConectado;
	}

	@Override
	public void setUsuarioConectado(Usuario usuario) {
		log.info("Estableciendo usuario conectado");
		this.usuarioConectado = usuario;
	}
}