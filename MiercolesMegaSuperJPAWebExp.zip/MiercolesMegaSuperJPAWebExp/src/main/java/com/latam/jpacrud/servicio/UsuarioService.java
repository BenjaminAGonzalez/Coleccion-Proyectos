package com.latam.jpacrud.servicio;

import com.latam.jpacrud.modelo.Usuario;
import com.latam.jpacrud.vo.NumberVO;
import com.latam.jpacrud.vo.UsuarioVO;

public interface UsuarioService {
	
	public UsuarioVO add(Usuario usuario);
	
	public UsuarioVO delete(Usuario usuario);
	
	public UsuarioVO update(Usuario usuario);
	
	public UsuarioVO findById(Integer id);
	
	public UsuarioVO getAllUsuarios();
	
	public UsuarioVO findByNombreAndClave(String nombre, String clave);
	
	public UsuarioVO login(String nombre, String clave);
	
	public UsuarioVO findByRut(Integer rut);
	
	public UsuarioVO getPage(Integer pagina, Integer cantidad);
	
	NumberVO getPageCount(long registrosPorPagina);

}
