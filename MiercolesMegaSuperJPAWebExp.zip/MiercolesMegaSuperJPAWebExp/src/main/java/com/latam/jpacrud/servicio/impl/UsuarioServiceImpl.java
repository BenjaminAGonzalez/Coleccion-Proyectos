package com.latam.jpacrud.servicio.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.latam.jpacrud.MiercolesMegaSuperJPAWebExpApplication;
import com.latam.jpacrud.dao.UsuarioRepository;
import com.latam.jpacrud.modelo.Usuario;
import com.latam.jpacrud.servicio.UsuarioService;
import com.latam.jpacrud.vo.NumberVO;
import com.latam.jpacrud.vo.UsuarioVO;

@Service
public class UsuarioServiceImpl implements UsuarioService {

	
	private static final Logger log = LoggerFactory.getLogger(MiercolesMegaSuperJPAWebExpApplication.class);
	
	@Autowired
	UsuarioRepository dao;
	
	UsuarioVO respuesta;

	
	@Override
	@Transactional
	public UsuarioVO add(Usuario usuario) {
	
		respuesta = new UsuarioVO(new ArrayList<Usuario>(), "Ha ocurrido un error", "104");
		
		try {
			dao.save(usuario);
			respuesta.setMensaje(String.format("Se ha guardado correctamente al usuario %s", usuario.getNombre()));
			respuesta.setCodigo("0");
		} catch (Exception e) {
			log.trace("Usuario Service: Error al guardar usuario");
		}
		return respuesta;
	}
	
	
	@Override
	@Transactional
	public UsuarioVO delete(Usuario usuario) {
		
		respuesta = new UsuarioVO(new ArrayList<Usuario>(), "Ha ocurrido un error", "106");
		
		try {
			dao.delete(usuario);
			respuesta.setMensaje("Se ha eliminado con éxito al usuario");
			respuesta.setCodigo("0");
		} catch(Exception e) {
			log.trace("Usuario service: Error al eliminar usuario", e);
		}
		return respuesta;
		
	}
	
	
	
	@Override
	@Transactional
	public UsuarioVO update(Usuario usuario) {
		
		respuesta = new UsuarioVO(new ArrayList<Usuario>(), "Ha ocurrido un error", "106");
		
		try {
			dao.save(usuario);
			respuesta.setMensaje(String.format("Se ha actualizado con éxito al usuario%s", usuario.getNombre()));
			respuesta.setCodigo("0");
		} catch(Exception e) {
			log.trace("Usuario service: Error al hacer el update usuario", e);
		}
		return respuesta;
		
	}
	
	
	@Override
	@Transactional(readOnly = true)
	public UsuarioVO findById(Integer id) {
		
		respuesta = new UsuarioVO(new ArrayList<Usuario>(), "Ha ocurrido un error", "107");
		try {
			Usuario usuario = dao.findById(id).get();
			respuesta.getUsuarios().add(usuario);
			respuesta.setMensaje("Usuario encontrado correctamente");
			respuesta.setCodigo("0");
		} catch(Exception e) {
			log.trace("Usuario Service: Error en el método findById", e);
		}
		
		return respuesta;
	}
	
	
	@Override
	@Transactional(readOnly=true)
	public UsuarioVO getAllUsuarios() {
		respuesta = new UsuarioVO(new ArrayList<Usuario>(), "Ha ocurrido un error", "102");
		try {
			ArrayList<Usuario> usuarios = (ArrayList<Usuario>)dao.findAll();
			respuesta.setUsuarios(usuarios);
			respuesta.setMensaje(String.format("Se encontraron %d registro/s", respuesta.getUsuarios().size()));
			respuesta.setCodigo("0");
		} catch(Exception e) {
			log.trace("Usuario Service: Error en método getAllUsuarios", e);
		}

		return respuesta;
	}
	
	
	@Override
	@Transactional(readOnly=true)
	public UsuarioVO findByNombreAndClave(String nombre, String clave) {
		
		respuesta = new UsuarioVO(new ArrayList<Usuario>(), "Ha ocurrido un error", "101");
		try {
			 List<Usuario> usuarios = dao.findByNombreAndClave(nombre, clave);
			 if (usuarios.size()>0) {
				 respuesta.setUsuarios(usuarios);
				 respuesta.setMensaje("Usuario/s encontrados correctamente");
				 respuesta.setCodigo("0");
			 } else {
				 respuesta.setMensaje("Usuario/s no encontrados");
				 respuesta.setCodigo("0");
			 }
		} catch (Exception e) {
			log.trace("Usuario service: Error en el método findByNombreAndClave", e);
		}
		
		return respuesta;
	} 
	
	
	@Override
	@Transactional(readOnly=true)
	public UsuarioVO login(String nombre, String clave) {
		respuesta = new UsuarioVO(new ArrayList<Usuario>(), "Credenciales incorrectas", "103");
		
		if(nombre.length()==0 || clave.length()==0) {
			respuesta.setMensaje("Logeese por favor");
			return respuesta;
		}
		
		respuesta = findByNombreAndClave(nombre, clave);
		
		if(respuesta.getCodigo().endsWith("0")) {
			respuesta.setMensaje(String.format("Bienvenido%s",  respuesta.getUsuarios().get(0).getNombre()));
		}
		
		return respuesta;
	}
	
	
	@Override
	@Transactional(readOnly=true)
	public UsuarioVO findByRut(Integer rut) {
			
		respuesta = new UsuarioVO(new ArrayList<Usuario>(), "Ha ocurrido un error", "110");
		
		if (rut == null) {
			respuesta.setMensaje("Rut viene como null");
			return respuesta;
		}
		
		try {
			List<Usuario> usuarios = dao.findByRut(rut);
			if (usuarios.size()>0) {
				respuesta.setUsuarios(usuarios);
				respuesta.setMensaje("Se ha recuperado con éxito uno o más registros");
				respuesta.setCodigo("0");
			} else {
				respuesta.setMensaje("Registro no encontrado");
				respuesta.setCodigo("110");
			}
		} catch (Exception e) {
			log.trace("Error", e);
		}
		
		return respuesta;
	}
	
	
	
	@Override
	@Transactional(readOnly = true)
	public UsuarioVO getPage(Integer pagina, Integer cantidad) {
		respuesta = new UsuarioVO(new ArrayList<Usuario>(), "Ha ocurrido un error", "108" );
		try {
			Pageable pageable = PageRequest.of(pagina,cantidad);
			Page<Usuario> responsePage = dao.findAll(pageable);
			respuesta.setUsuarios(responsePage.getContent());
			respuesta.setMensaje(String.format("Se ha/n encontrado %d registro/s", respuesta.getUsuarios().size()));
			respuesta.setCodigo("0");
		} catch (Exception e) {
			log.trace("Usuario Service: Error en getPage", e);
		}
		return respuesta;
	}
	
	
	
	@Override
	@Transactional(readOnly = true)
	public NumberVO getPageCount(long registrosPorPagina) {
		NumberVO respuesta = new NumberVO(0, "Ha ocurrido un error", "109" );
		try {
			long registros = dao.count();
			if(registrosPorPagina == 0 && registros == 0) {
				respuesta.setValor(1);
			}else {
				respuesta.setValor((registros/registrosPorPagina) + (registros % registrosPorPagina == 0 ? 0 : 1));
			}
			respuesta.setCodigo("201");
			respuesta.setMensaje(String.format("Hay %d paginas", respuesta.getValor()));

		} catch (Exception e) {
			log.trace("Usuario Service: Error en getPageCount", e);
		}
		return respuesta;
	}

}
