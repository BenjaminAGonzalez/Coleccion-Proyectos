package com.latam.jpacrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiercolesMegaSuperJPAWebExpApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiercolesMegaSuperJPAWebExpApplication.class, args);
	}

}
