package com.latam.jpacrud.vo;

import java.util.List;

import com.latam.jpacrud.modelo.Usuario;

public class UsuarioVO extends GenericVO {
	
	List<Usuario> usuarios;

	public UsuarioVO(List<Usuario> usuarios, String mensaje, String codigo) {
		super(mensaje, codigo);
		this.usuarios=usuarios;
	}
	
	/**
	 * 
	 */
	public UsuarioVO() {
		super();
		// TODO Auto-generated constructor stub
	}



	/**
	 * @param mensaje
	 * @param codigo
	 * @param nombre
	 */
	public UsuarioVO(String mensaje, String codigo, String nombre) {
		super(mensaje, codigo, nombre);
		// TODO Auto-generated constructor stub
	}



	/**
	 * @return the usuarios
	 */
	public List<Usuario> getUsuarios() {
		return usuarios;
	}

	/**
	 * @param usuarios the usuarios to set
	 */
	public void setUsuarios(List<Usuario> usuarios) {
		this.usuarios = usuarios;
	}

	@Override
	public String toString() {
		return "UsuarioVO [usuarios=" + usuarios + "]";
	}
	
	

}
