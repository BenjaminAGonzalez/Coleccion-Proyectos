package com.latam.jpacrud.vo;


public class NumberVO {
	
	long valor;
	String codigo;
	String mensaje;
	
	
	/**
	 * @param valor
	 * @param codigo
	 * @param nombre
	 */
	public NumberVO(long valor, String codigo, String mensaje) {
		super();
		this.valor = valor;
		this.codigo = codigo;
		this.mensaje = mensaje;
	}
	
	
	/**
	 * @return the valor
	 */
	public long getValor() {
		return valor;
	}
	/**
	 * @param valor the valor to set
	 */
	public void setValor(long valor) {
		this.valor = valor;
	}
	/**
	 * @return the codigo
	 */
	public String getCodigo() {
		return codigo;
	}
	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}


	/**
	 * @return the mensaje
	 */
	public String getMensaje() {
		return mensaje;
	}


	/**
	 * @param mensaje the mensaje to set
	 */
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}


	@Override
	public String toString() {
		return "NumberVO [valor=" + valor + ", codigo=" + codigo + ", mensaje=" + mensaje + "]";
	}
	

}
