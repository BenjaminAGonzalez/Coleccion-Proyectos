package com.latam.jpacrud.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.latam.jpacrud.modelo.Usuario;

public interface UsuarioRepository extends CrudRepository<Usuario, Integer>, PagingAndSortingRepository<Usuario, Integer> { 
	
	// implicitamente están todos los métodos (y más) para hacer un crud
	// podemos crear otros métodos específicos 
	
	@Query(value = "select * from usuario where nombre=?1 and clave=?2", nativeQuery=true)
	public List<Usuario> findByNombreAndClave(String nombre, String clave);
	
	@Query(value = "select * from usuario where rut=?1", nativeQuery=true)
	public List<Usuario> findByRut(Integer rut);

}
