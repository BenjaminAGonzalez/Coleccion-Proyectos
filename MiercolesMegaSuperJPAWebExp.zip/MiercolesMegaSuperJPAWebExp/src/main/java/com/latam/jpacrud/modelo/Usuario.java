package com.latam.jpacrud.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Usuario {
	
	@Id
	@Column(columnDefinition = "NUMERIC(19,0)")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idusuario;
	private String nombre;
	private String clave;
	@Column(columnDefinition = "NUMERIC(19,0)")
	private Integer rut;
	private String dv;
	
	
	
	/**
	 * @param idusuario
	 * @param nombre
	 * @param clave
	 * @param rut
	 * @param dv
	 */
	public Usuario(Integer idusuario, String nombre, String clave, Integer rut, String dv) {
		super();
		this.idusuario = idusuario;
		this.nombre = nombre;
		this.clave = clave;
		this.rut = rut;
		this.dv = dv;
	}
	
	
	/**
	 * 
	 */
	public Usuario() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	/**
	 * @return the idusuario
	 */
	public Integer getIdusuario() {
		return idusuario;
	}
	/**
	 * @param idusuario the idusuario to set
	 */
	public void setIdusuario(Integer idusuario) {
		this.idusuario = idusuario;
	}
	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * @return the clave
	 */
	public String getClave() {
		return clave;
	}
	/**
	 * @param clave the clave to set
	 */
	public void setClave(String clave) {
		this.clave = clave;
	}
	/**
	 * @return the rut
	 */
	public Integer getRut() {
		return rut;
	}
	/**
	 * @param rut the rut to set
	 */
	public void setRut(Integer rut) {
		this.rut = rut;
	}
	/**
	 * @return the dv
	 */
	public String getDv() {
		return dv;
	}
	/**
	 * @param dv the dv to set
	 */
	public void setDv(String dv) {
		this.dv = dv;
	}
	
	
	@Override
	public String toString() {
		return "Usuario [idusuario=" + idusuario + ", nombre=" + nombre + ", clave=" + clave + ", rut=" + rut + ", dv="
				+ dv + "]";
	}
	
	
	

}
