package com.latam.jpacrud.vo;

public class GenericVO {
	
	String mensaje;
	String codigo;
	String nombre;
	
	
	/**
	 * @param mensaje
	 * @param codigo
	 * @param nombre
	 */
	public GenericVO(String mensaje, String codigo, String nombre) {
		super();
		this.mensaje = mensaje;
		this.codigo = codigo;
		this.nombre = nombre;
	}

	/**
	 * @param mensaje
	 * @param codigo
	 */
	public GenericVO(String mensaje, String codigo) {
		super();
		this.mensaje = mensaje;
		this.codigo = codigo;
	}



	/**
	 * 
	 */
	public GenericVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the mensaje
	 */
	public String getMensaje() {
		return mensaje;
	}
	/**
	 * @param mensaje the mensaje to set
	 */
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
	/**
	 * @return the codigo
	 */
	public String getCodigo() {
		return codigo;
	}
	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	
	@Override
	public String toString() {
		return "GenericVO [mensaje=" + mensaje + ", codigo=" + codigo + ", nombre=" + nombre + "]";
	}
	
	
	

}
