package com.latam.jpacrud.servicio;

import com.latam.jpacrud.modelo.Usuario;

public interface SecurityService {
	
	public boolean isLoggedIn();
	public void setUsuarioConectado(Usuario usuario);
	public Usuario getUsuarioConectado();
	
}

