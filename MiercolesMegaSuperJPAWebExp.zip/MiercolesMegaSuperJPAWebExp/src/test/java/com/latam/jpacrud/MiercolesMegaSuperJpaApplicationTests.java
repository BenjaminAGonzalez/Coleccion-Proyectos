package com.latam.jpacrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiercolesMegaSuperJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
