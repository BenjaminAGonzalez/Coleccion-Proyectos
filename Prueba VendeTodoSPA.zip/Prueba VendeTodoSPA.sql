SET check_function_bodies = false;

create user "Admin" with password '4321';

grant all privileges on database "Prueba" to "Admin";

/* Table 'Empleados' */
CREATE TABLE "empleados"(
  id numeric NOT NULL,
  nombre varchar,
  apellido varchar,
  fecha_nacimiento date,
  direccion varchar,
  region varchar,
  ciudad varchar,
  pais varchar,
  telefono numeric,
  cargo varchar,
  PRIMARY KEY(id)
);

/* Table 'Clientes' */
CREATE TABLE "clientes"(
  id numeric NOT NULL,
  nombre_empresa varchar,
  nombre_contacto varchar,
  email varchar,
  direccion varchar,
  region varchar,
  ciudad varchar,
  pais varchar,
  codigo_postal numeric,
  telefono numeric,
  PRIMARY KEY(id)
);



/* Table 'Despachadores' */
CREATE TABLE "despachadores"(
  id integer NOT NULL,
  nombre varchar,
  telefono_empresa numeric,
  PRIMARY KEY(id)
);

/* Table 'Categoria' */
CREATE TABLE "categoria"
  (nombre_categoria varchar NOT NULL, PRIMARY KEY(nombre_categoria));

/* Table 'Proveedores' */
CREATE TABLE "proveedores"(
  nombre_empresa varchar NOT NULL,
  nombre_contacto varchar,
  direccion varchar,
  region varchar,
  ciudad varchar,
  telefono numeric,
  PRIMARY KEY(nombre_empresa)
);


/* Table 'Productos' */
CREATE TABLE "productos"(
  id numeric NOT NULL,
  precio numeric,
  stock numeric NOT NULL,
  descontinuado boolean NOT NULL,
  "Categoria_nombre_categoria" varchar NOT NULL,
  PRIMARY KEY(id)
);



/* Table 'Ordenes' */
CREATE TABLE "ordenes"(
  id numeric NOT NULL,
  "Despachadores_id" integer NOT NULL,
  "Clientes_id" numeric NOT NULL,
  fecha_requerimiento date,
  fecha_envio date,
  nombre_comprador varchar,
  direccion varchar,
  codigo_postal varchar,
  ciudad varchar,
  region varchar,
  pais varchar,
  via_envio varchar,
  PRIMARY KEY(id)
);



/* Table 'Compra de Productos' */
CREATE TABLE "compra de productos"(
  "Proveedores_nombre_empresa" varchar NOT NULL,
  "Productos_id" numeric NOT NULL,
  cantidad numeric NOT NULL,
  valor numeric,
  PRIMARY KEY("Proveedores_nombre_empresa")
);



/* Table 'Venta' */
CREATE TABLE "venta"(
  "Empleados_id" numeric NOT NULL,
  "Productos_id" numeric NOT NULL,
  "Ordenes_id" numeric NOT NULL,
  cantidad numeric,
  descuento numeric
);



-----------------------------------------------------------------------------

/* Relation 'Categoria_Productos' */
ALTER TABLE "productos"
  ADD CONSTRAINT "Categoria_Productos"
    FOREIGN KEY ("Categoria_nombre_categoria")
      REFERENCES "categoria" (nombre_categoria);

/* Relation 'Proveedores_Compra de Productos' */
ALTER TABLE "compra de productos"
  ADD CONSTRAINT "Proveedores_Compra de Productos"
    FOREIGN KEY ("Proveedores_nombre_empresa")
      REFERENCES "proveedores" (nombre_empresa);

/* Relation 'Productos_Compra de Productos' */
ALTER TABLE "compra de productos"
  ADD CONSTRAINT "Productos_Compra de Productos"
    FOREIGN KEY ("Productos_id") REFERENCES "productos" (id);

/* Relation 'Empleados_Venta' */
ALTER TABLE "venta"
  ADD CONSTRAINT "Empleados_Venta"
    FOREIGN KEY ("Empleados_id") REFERENCES "empleados" (id);

/* Relation 'Productos_Venta' */
ALTER TABLE "venta"
  ADD CONSTRAINT "Productos_Venta"
    FOREIGN KEY ("Productos_id") REFERENCES "productos" (id);

/* Relation 'Ordenes_Venta' */
ALTER TABLE "venta"
  ADD CONSTRAINT "Ordenes_Venta"
    FOREIGN KEY ("Ordenes_id") REFERENCES "ordenes" (id);

/* Relation 'Despachadores_Ordenes' */
ALTER TABLE "ordenes"
  ADD CONSTRAINT "Despachadores_Ordenes"
    FOREIGN KEY ("Despachadores_id") REFERENCES "despachadores" (id);

/* Relation 'Clientes_Ordenes' */
ALTER TABLE "ordenes"
  ADD CONSTRAINT "Clientes_Ordenes"
    FOREIGN KEY ("Clientes_id") REFERENCES "clientes" (id);
    
 -------------------------------------------------------------------
 --Aqui importamos las tablas desde nuestro Moon Modeler, y crea las llaves foraneas como alter table - foreign key
   
insert into empleados (id, nombre, apellido, fecha_nacimiento, direccion, region, ciudad, pais, telefono, cargo)
values (1, 'Empleado1', 'Apellido1', TO_DATE('12/02/1970','dd/mm/yyyy'), 'direccion1', 'region1','ciudad1','pais1',1234567,'Vendedor');
insert into empleados  (id, nombre, apellido, fecha_nacimiento, direccion, region, ciudad, pais, telefono, cargo)
values (2, 'Empleado2', 'Apellido2', TO_DATE('13/03/1970','dd/mm/yyyy'), 'direccion2', 'region2','ciudad2','pais2',1234568,'Programador'); 
insert into empleados  (id, nombre, apellido, fecha_nacimiento, direccion, region, ciudad, pais, telefono, cargo)
values (3, 'Empleado3', 'Apellido3', TO_DATE('14/04/1970','dd/mm/yyyy'), 'direccion3', 'region3','ciudad3','pais3',1234569,'Conserje');
insert into empleados  (id, nombre, apellido, fecha_nacimiento, direccion, region, ciudad, pais, telefono, cargo)
values (4, 'Empleado4', 'Apellido4', TO_DATE('15/05/1970','dd/mm/yyyy'), 'direccion4', 'region4','ciudad4','pais4',1234560,'Supervisor');
insert into empleados  (id, nombre, apellido, fecha_nacimiento, direccion, region, ciudad, pais, telefono, cargo)
values (5, 'Empleado5', 'Apellido5', TO_DATE('16/06/1970','dd/mm/yyyy'), 'direccion5', 'region5','ciudad5','pais5',1234562,'Jefe de area');

insert into clientes(id, nombre_empresa, nombre_contacto, email, direccion, region, ciudad, pais, codigo_postal, telefono)
values(1, 'Empresa1', 'Contacto1', 'cliente01@hotmail.com', 'direccion6', 'region6', 'ciudad6', 'pais6', 321321, 425252);
insert into clientes(id, nombre_empresa, nombre_contacto, email, direccion, region, ciudad, pais, codigo_postal, telefono)
values(2, 'Empresa2', 'Contacto2', 'cliente02@hotmail.com', 'direccion7', 'region7', 'ciudad7', 'pais7', 123123, 231232);
insert into clientes(id, nombre_empresa, nombre_contacto, email, direccion, region, ciudad, pais, codigo_postal, telefono)
values(3, 'Empresa3', 'Contacto3', 'cliente03@hotmail.com', 'direccion8', 'region8', 'ciudad8', 'pais8', 450503, 232323);
insert into clientes(id, nombre_empresa, nombre_contacto, email, direccion, region, ciudad, pais, codigo_postal, telefono)
values(4, 'Empresa4', 'Contacto4', 'cliente04@gmail.com', 'direccion9', 'region9', 'ciudad9', 'pais9', 905813, 4568412);
insert into clientes(id, nombre_empresa, nombre_contacto, email, direccion, region, ciudad, pais, codigo_postal, telefono)
values(5, 'Empresa5', 'Contacto5', 'cliente05@gmail.com', 'direccion10', 'region10', 'ciudad10', 'pais10', 512345, 458741);

insert into despachadores (id, nombre, telefono_empresa) values (1, 'nombre1', 452970);
insert into despachadores (id, nombre, telefono_empresa) values (2, 'nombre2', 425671);
insert into despachadores (id, nombre, telefono_empresa) values (3, 'nombre3', 432314);
insert into despachadores (id, nombre, telefono_empresa) values (4, 'nombre4', 123561);
insert into despachadores (id, nombre, telefono_empresa) values (5, 'nombre5', 627212);

insert into categoria (nombre_categoria) values ('categoria1');
insert into categoria (nombre_categoria) values ('categoria2');
insert into categoria (nombre_categoria) values ('categoria3');
insert into categoria (nombre_categoria) values ('categoria4');
insert into categoria (nombre_categoria) values ('categoria5');

insert into proveedores (nombre_empresa,nombre_contacto,direccion,region,ciudad,telefono)
values ('Empresa1','contacto1','direccion1','region1','ciudad1',345161);
insert into proveedores (nombre_empresa,nombre_contacto,direccion,region,ciudad,telefono)
values ('Empresa2','contacto2','direccion2','region2','ciudad2',325416);
insert into proveedores (nombre_empresa,nombre_contacto,direccion,region,ciudad,telefono)
values ('Empresa3','contacto3','direccion3','region3','ciudad3',321541);
insert into proveedores (nombre_empresa,nombre_contacto,direccion,region,ciudad,telefono)
values ('Empresa4','contacto4','direccion4','region4','ciudad4',626712);
insert into proveedores (nombre_empresa,nombre_contacto,direccion,region,ciudad,telefono)
values ('Empresa5','contacto5','direccion5','region5','ciudad5',582952);
insert into proveedores (nombre_empresa,nombre_contacto,direccion,region,ciudad,telefono)
values ('Empresa6','contacto6','direccion6','region6','ciudad6',246161);

insert into productos (id, precio, stock, descontinuado, "Categoria_nombre_categoria") values (1, 2000, 5, true, 'categoria1'); --Solo nos permite ingresar valores que ya existan en tabla categoria
insert into productos (id, precio, stock, descontinuado, "Categoria_nombre_categoria") values (2, 5000, 10, true, 'categoria2');
insert into productos (id, precio, stock, descontinuado, "Categoria_nombre_categoria") values (3, 10000, 3, false , 'categoria3');
insert into productos (id, precio, stock, descontinuado, "Categoria_nombre_categoria") values (4, 15000, 7, true, 'categoria2');
insert into productos (id, precio, stock, descontinuado, "Categoria_nombre_categoria") values (5, 1000, 12, true, 'categoria5');

insert into ordenes (id, "Despachadores_id", "Clientes_id", fecha_requerimiento, fecha_envio, nombre_comprador, direccion, codigo_postal, ciudad, region, pais, via_envio)
values (1, 1, 1, TO_DATE('12/02/2020','dd/mm/yyyy'), TO_DATE('15/02/2020','dd/mm/yyyy'), 'nombre1', 'direccion1', '323135','ciudad1','region1','pais1','camion');
insert into ordenes (id, "Despachadores_id", "Clientes_id", fecha_requerimiento, fecha_envio, nombre_comprador, direccion, codigo_postal, ciudad, region, pais, via_envio)
values (2, 5, 4, TO_DATE('17/05/2020','dd/mm/yyyy'), TO_DATE('20/05/2020','dd/mm/yyyy'), 'nombre2', 'direccion2', '361772','ciudad2','region2','pais2','express');
insert into ordenes (id, "Despachadores_id", "Clientes_id", fecha_requerimiento, fecha_envio, nombre_comprador, direccion, codigo_postal, ciudad, region, pais, via_envio)
values (3, 4, 3, TO_DATE('20/04/2020','dd/mm/yyyy'), TO_DATE('21/04/2020','dd/mm/yyyy'), 'nombre3', 'direccion3', '312461','ciudad3','region3','pais3','aerea');
insert into ordenes (id, "Despachadores_id", "Clientes_id", fecha_requerimiento, fecha_envio, nombre_comprador, direccion, codigo_postal, ciudad, region, pais, via_envio)
values (4, 4, 3, TO_DATE('23/07/2020','dd/mm/yyyy'), TO_DATE('24/07/2020','dd/mm/yyyy'), 'nombre4', 'direccion4', '561234','ciudad4','region4','pais4','aerea');
insert into ordenes (id, "Despachadores_id", "Clientes_id", fecha_requerimiento, fecha_envio, nombre_comprador, direccion, codigo_postal, ciudad, region, pais, via_envio)
values (5, 3, 1, TO_DATE('25/03/2020','dd/mm/yyyy'), TO_DATE('28/03/2020','dd/mm/yyyy'), 'nombre5', 'direccion5', '325165','ciudad5','region5','pais5','maritima');

insert into "compra de productos"("Proveedores_nombre_empresa","Productos_id",cantidad,valor)
values ('Empresa1',1, 50, 5000);
insert into "compra de productos"("Proveedores_nombre_empresa","Productos_id",cantidad,valor)
values ('Empresa2',2, 20, 10000);
insert into "compra de productos"("Proveedores_nombre_empresa","Productos_id",cantidad,valor)
values ('Empresa3',3, 25, 25000);
insert into "compra de productos"("Proveedores_nombre_empresa","Productos_id",cantidad,valor)
values ('Empresa4',4, 60, 3000);
insert into "compra de productos"("Proveedores_nombre_empresa","Productos_id",cantidad,valor)
values ('Empresa5',5, 100, 50000);
insert into "compra de productos"("Proveedores_nombre_empresa","Productos_id",cantidad,valor)
values ('Empresa6',3, 21, 3125);

insert into venta ("Empleados_id", "Productos_id","Ordenes_id",cantidad,descuento)
values (1, 1, 1, 3, 0.3);
insert into venta ("Empleados_id", "Productos_id","Ordenes_id",cantidad,descuento)
values (2, 2, 2, 5, 0.1);
insert into venta ("Empleados_id", "Productos_id","Ordenes_id",cantidad,descuento)
values (3, 3, 3, 2, 0.3);
insert into venta ("Empleados_id", "Productos_id","Ordenes_id",cantidad,descuento)
values (4, 4, 4, 1, 0.2);
insert into venta ("Empleados_id", "Productos_id","Ordenes_id",cantidad,descuento)
values (5, 5, 5, 5, 0);
insert into venta ("Empleados_id", "Productos_id","Ordenes_id",cantidad,descuento)
values (5, 3, 5, 5, 0);

select * from empleados;
select * from clientes;
select * from despachadores;
select * from categoria;
select * from proveedores ;
select * from productos ;
select * from ordenes ;
select * from "compra de productos";
select * from venta ; --Confirmamos ingreso a las tablas

select 
c.id as "ID Cliente", 
c.ciudad as "Ciudad",
c.nombre_empresa as "Nombre",--Selecciono la ID de cliente y la ID de Orden
sum ((v.cantidad * p.precio) * (1 - v.descuento))  as "Monto total de venta" --Sumo las ventas que se repiten, multiplico la cantidad con el precio, y le aplico un descuento al final
from clientes as c
inner join ordenes as o on c.id = o."Clientes_id"
inner join venta as v on o.id = v."Ordenes_id"
inner join productos as p on v."Productos_id" = p.id --Junto las tablas ordenes, venta, productos y clientes
group by "ID Cliente", "Ciudad" --Agrupo por ID y Ciudad
order by "Monto total de venta" desc;

select 
cdp."Proveedores_nombre_empresa" as "Nombres de las empresas", 
v."Productos_id" as "ID Productos" , 
sum(v.cantidad) as "Cantidad Total" --Sumo la cantidad total de productos vendidos con cada ID
from "compra de productos" as cdp
inner join productos as p on p.id = cdp."Productos_id"
inner join venta as v on v."Productos_id" = p.id
group by cdp."Proveedores_nombre_empresa", v."Productos_id"
order by "Cantidad Total" desc;  --Listo todas las empresas que hagan venta con el mismo producto, y evaluo con cual comprar en largos volumenes


