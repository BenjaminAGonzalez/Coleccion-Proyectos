package com.example.HolaMundoSpringMVC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HolaMundoSpringMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
