package com.example.HolaMundoSpringMVC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HolaMundoSpringMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(HolaMundoSpringMvcApplication.class, args);
	}

}
