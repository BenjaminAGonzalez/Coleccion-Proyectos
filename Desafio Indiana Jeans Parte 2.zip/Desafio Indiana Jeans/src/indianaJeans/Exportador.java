/**
 * 
 */
package indianaJeans;

import java.util.List;

/**
 * @author Benja
 *
 */
public abstract class Exportador {
	
	public void exportar(String nombreArchivo, String ruta, List<Producto>listaProductos) {
	} 

}