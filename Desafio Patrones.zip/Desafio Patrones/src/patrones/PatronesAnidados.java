package patrones;

import java.util.Scanner;

public class PatronesAnidados {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Ingresar con cuantos caracteres se crearan las figuras: ");
		int masternum = sc.nextInt();
		CrearCuadrado(masternum);
		System.out.println();
		CrearZeta(masternum);
		System.out.println();
		CrearX(masternum);
		System.out.println();
		CrearCuadroEsp(masternum);
		sc.close();

	}

	public static void CrearCuadrado (int a) {
		for(int i=1;  i <= a ; i++) {
			for (int i2= 1; i2 <= a ; i2++) {
				if((i > 1 && i < a) && (i2 > 1 && i2 < a)) {
						System.out.print(" ");
					}
					else {
						System.out.print("*");
					}

				}
				System.out.println();
			}
		}

	public static void CrearZeta (int a) {
		int derecha = a;
		for(int i=1;  i <= a ; i++) {
			for (int i2= 1; i2 <= a ; i2++) {
				if((i > 1 && i < a) && (i2 != derecha)) {
					System.out.print(" ");
				}
				else {
					System.out.print("*");
				}
				
			}
			derecha--;
			System.out.println();
		}
		
	}
	public static void CrearX (int a) {
		int derecha = a;
		for(int i = 1; i <= a; i++ ) {
			for  (int i2 = 1; i2 <= a; i2++) {
				if(i2 == i) {
					System.out.print("X");
				}
				else if(i2 == derecha) {
					System.out.print("X");
				}
				else{
					System.out.print(" ");
				}
			}
			derecha--;
			System.out.println();
		}
	}
	public static void CrearCuadroEsp (int a) {
		for(int i=1;  i <= a ; i++) {
			for (int i2= 1; i2 <= a ; i2++) {
				if(i2 == a && i < a){
						System.out.print(" ");
					}
				else if(i2 == 1 && i > 1) {
					System.out.print(" ");
				}
					else {
						System.out.print("*");
					}

				}
				System.out.println();
			}
	}
	
}