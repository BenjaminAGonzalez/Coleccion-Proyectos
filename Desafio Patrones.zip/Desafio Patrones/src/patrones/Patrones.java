package patrones;

import java.util.Scanner;

public class Patrones {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Ingresar cuantos caracteres se mostraran por patron: ");
		int n = sc.nextInt();
		int numeros = 1;
		for(int i=0; i<n; i++) {
			if(i%2==0) 
				System.out.printf("*");
			else
				System.out.printf(".");
		}
		System.out.printf("\n");
		
		for (int num = 0; num<n ; num++) {
			if(numeros == 4) {
				System.out.print(numeros);
				numeros = 1;
			} else {
				System.out.print(numeros);
				numeros++;
			}
			
		}
		
		System.out.printf("\n");
		
		for(int lineas=1; lineas<=n; lineas++) {
			if(lineas%3==0) 
				System.out.printf("*");
			else
				System.out.printf("|");
		}
		System.out.printf("\n");
		sc.close();
	}
	
}
