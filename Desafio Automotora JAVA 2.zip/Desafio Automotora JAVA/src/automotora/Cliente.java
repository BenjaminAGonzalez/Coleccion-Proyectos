package automotora;

public class Cliente extends Persona {
	
	//ATRIBUTOS
	private int edad;
	
	//CONSTRUCTOR
	public Cliente (int edad) {
		this.edad = edad;
	}
	public Cliente() {
		
	}
	//GETS AND SETS
	public int getEdad() {
		return edad;
	}
	public void setEdad(int edad) {
		this.edad = edad;
	}
	
	
}
