/**
 * 
 */
package automotora;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * @author Benja
 *
 */
public class LibroVenta {
	
	private String nombreVenta;
	private String fechaVenta;
	
	/**
	 * @param nombreVenta
	 * @param fechaVenta
	 */
	public LibroVenta(String nombreVenta, String fechaVenta) {
		super();
		this.nombreVenta = nombreVenta;
		this.fechaVenta = fechaVenta;
	}
	
	public LibroVenta() {
	}



	/**
	 * @return the nombreVenta
	 */
	public String getNombreVenta() {
		return nombreVenta;
	}



	/**
	 * @param nombreVenta the nombreVenta to set
	 */
	public void setNombreVenta(String nombreVenta) {
		this.nombreVenta = nombreVenta;
	}



	/**
	 * @return the fechaVenta
	 */
	public String getFechaVenta() {
		return fechaVenta;
	}



	/**
	 * @param fechaVenta the fechaVenta to set
	 */
	public void setFechaVenta(String fechaVenta) {
		this.fechaVenta = fechaVenta;
	}

	public void guardarVenta (Cliente cliente, Vehiculo vehiculo) {
		
		File crearcarpeta = new File("src/ficheros");
		File creararchivo = new File (crearcarpeta+"/"+nombreVenta+".txt"); //ARCHIVO SERA GUARDADO EN CREARCARPETA,  con nombre nombreVenta tipo .txt
		
		if(!crearcarpeta.exists()) { //Comprobar si carpeta no existe, si no existe, crearla
			try {
				if(crearcarpeta.mkdir()) {
					if(!creararchivo.exists()) { //Comprobar si archivo no existe, si no existe, crearlo
						
						creararchivo.createNewFile();
						FileWriter escritor = new FileWriter(creararchivo);
						BufferedWriter bufferedEscritor = new BufferedWriter(escritor);
						
						
						String fechaD = fechaVenta.substring(0, 2);
						String fechaM = fechaVenta.substring(2, 4);
						String fechaA = fechaVenta.substring(4, 8);
						
						int diasFecha = Integer.parseInt(fechaD);
						int mesesFecha = Integer.parseInt(fechaM);
						int anioFecha = Integer.parseInt(fechaA);
						
						ArrayList<String> lista = new ArrayList<String>();
						lista.add(vehiculo.patente);
						lista.add(String.valueOf(cliente.getEdad()));
						lista.add(nombreVenta);
						
						for (Iterator iterator = lista.iterator(); iterator.hasNext();) { //Formato para crear un iterator
							String elementoAEscribir = (String) iterator.next();
							bufferedEscritor.write(elementoAEscribir);
							bufferedEscritor.newLine();
						}
						bufferedEscritor.write(diasFecha + "/"); //Append toma una cadena de caracteres, y escribe los caracteres desde indice 0 hasta 2
						bufferedEscritor.write(mesesFecha + "/"); //Append toma una cadena de caracteres, y escribe los caracteres desde indice 2 hasta 4
						bufferedEscritor.write(anioFecha + ".");//Append toma una cadena de caracteres, y escribe los caracteres desde indice 4 hasta 8
						bufferedEscritor.close();
						System.out.println("Fichero creado exitosamente");
						
					}else {
						System.out.println("Fichero ya existe");
					}
				}
			}catch(IOException | NumberFormatException  ex) { //Catch para errores en caso de que crear fichero presente problemas
				System.out.println("Error: " + ex.getMessage());
			}

		}else {
			System.out.println("Directorio ya existe");
		}
	}	
}
