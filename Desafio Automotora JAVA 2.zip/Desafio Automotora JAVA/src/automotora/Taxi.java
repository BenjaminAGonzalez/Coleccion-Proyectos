package automotora;

import java.util.Scanner;

public class Taxi extends Vehiculo {

	//ATRIBUTOS

	private int valorPasaje;

	//CONSTRUCTOR
	public Taxi(int valorPasaje) {
		this.valorPasaje = valorPasaje;
	}

	public Taxi() {

	}
	//GETS AND SETS
	public int getValorPasaje() {
		return valorPasaje;
	}

	public void setValorPasaje(int valorPasaje) {
		this.valorPasaje = valorPasaje;
	}
	
	public void pagarPasaje() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Ingrese cantidad de dinero entregado por cliente");
		int dinero = sc.nextInt();
		if (dinero > valorPasaje) {
			System.out.println("Muchas gracias por preferirnos, su vuelto es: " + (dinero- valorPasaje));
		}else if (dinero < valorPasaje) {
			System.out.println("Favor pagar el total del costo de pasaje, el cual es: " + valorPasaje);
		}else if (dinero == valorPasaje) {
			System.out.println("Muchas gracias por preferirnos.");
		}
		sc.close();
		
	}
	
}
