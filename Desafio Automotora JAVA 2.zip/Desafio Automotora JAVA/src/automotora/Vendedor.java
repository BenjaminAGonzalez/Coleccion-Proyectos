package automotora;

public class Vendedor extends Persona{
	
	//ATRIBUTOS
	private String direccion;
	
	//CONSTRUCTOR
	public Vendedor(String direccion) {
		this.direccion = direccion;
	}
	public Vendedor() {
		
	}
	//GETS AND SETS
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	
}
