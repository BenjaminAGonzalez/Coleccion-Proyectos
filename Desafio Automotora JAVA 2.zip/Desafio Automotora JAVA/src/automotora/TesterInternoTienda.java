package automotora;

//TESTER PARA COMPROBAR FUNCIONAMIENTO CORRECTO DE SISTEMA

public class TesterInternoTienda {

	public static void main(String[] args) {
		
		Bus turbus = new Bus(30);
		Vehiculo auto = new Vehiculo("Rojo","CXYU-49");
		Cliente Martin = new Cliente(24);
		Minibus maxusEscolar = new Minibus("Escolar");
		Persona identidad = new Persona ("9.984.231-4", "Maria", 49);
		Taxi chevrolet = new Taxi(5000);
		Vendedor Jose = new Vendedor("Calle Las Rosas 439");
		Tienda miStock = new Tienda(Jose, Martin, auto, 44);
		LibroVenta nuevaVenta = new LibroVenta("ventaDiciembre","20122021");
		
		
		
		chevrolet.pagarPasaje(); //PROCESAR PAGO DE PASAJE
		System.out.println("La cantidad de asientos disponibles son "+turbus.asientosDisponibles()); //PROCESAR CANTIDAD DE ASIENTOS
		maxusEscolar.imprimeBus( turbus.cantidadDeAsientos,  auto.color,  auto.getPatente()); //IMPRIMIR TODOS LOS ATRIBUTOS DE CLASE MINIBUS
		System.out.println("Cantidad de stock es " + miStock.existeStock()); //IMPRIMIR CANTIDAD DE STOCK
		nuevaVenta.guardarVenta(Martin, auto); //CREAR .TXT DE VENTA REALIZADA

	}

}
