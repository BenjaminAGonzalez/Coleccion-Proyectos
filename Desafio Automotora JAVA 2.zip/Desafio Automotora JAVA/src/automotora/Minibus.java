package automotora;

public class Minibus extends Bus{
	
	//ATRIBUTOS

	private String tipoViaje;
	
	//CONSTRUCTOR
	public Minibus(String tipoViaje) {
		this.tipoViaje = tipoViaje;
	}
	public Minibus() {
		
	}
	//GETS AND SETS
	public String getTipoViaje() {
		return tipoViaje;
	}
	public void setTipoViaje(String tipoViaje) {
		this.tipoViaje = tipoViaje;
	}
	
	public void imprimeBus(int asientos, String color, String patente) {
		System.out.println(tipoViaje);
		System.out.println(asientos);
		System.out.println(color);
		System.out.println(patente);
	}
	
}
