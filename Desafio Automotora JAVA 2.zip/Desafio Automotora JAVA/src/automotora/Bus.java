package automotora;

public class Bus extends Vehiculo {
	
	//ATRIBUTOS

	protected  int cantidadDeAsientos;

	//CONSTRUCTOR
	public Bus(int cantidadDeAsientos) {
		this.cantidadDeAsientos = cantidadDeAsientos;
	}

	public Bus() {

	}

	//GETS AND SETS
	public int getCantidadDeAsientos() {
		return cantidadDeAsientos;
	}

	public void setCantidadDeAsientos(int cantidadDeAsientos) {
		this.cantidadDeAsientos = cantidadDeAsientos;
	}

	public int asientosDisponibles() {
		return cantidadDeAsientos;
	}
}
