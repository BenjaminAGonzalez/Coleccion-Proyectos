package automotora;

public class Tienda {
	
	//ATRIBUTOS
	private Vendedor vendedor;
	private Cliente cliente;
	private Vehiculo vehiculo;
	private int stock;
	
	//CONSTRUCTOR
	public Tienda(Vendedor vendedor, Cliente cliente, Vehiculo vehiculo, int stock) {
		this.vendedor = vendedor;
		this.cliente = cliente;
		this.vehiculo = vehiculo;
		this.stock = stock;
	}

	public Vendedor getVendedor() {
		return vendedor;
	}
	//GETS AND SETS
	public void setVendedor(Vendedor vendedor) {
		this.vendedor = vendedor;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Vehiculo getVehiculo() {
		return vehiculo;
	}

	public void setVehiculo(Vehiculo vehiculo) {
		this.vehiculo = vehiculo;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}
	
	public String existeStock () {
		return String.valueOf(stock); //Retornar valor como String segun lo solicitado por cliente
	}

}
