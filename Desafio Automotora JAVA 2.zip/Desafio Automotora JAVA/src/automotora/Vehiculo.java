package automotora;

public class Vehiculo {

	//ATRIBUTOS
	protected  String color;
	protected String patente;

	
	//CONSTRUCTOR
	public Vehiculo(String color, String patente) {

		this.color = color;
		this.patente = patente;
	}

	public Vehiculo() {

	}

	//GETS AND SETS
	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getPatente() {
		return patente;
	}

	public void setPatente(String patente) {
		this.patente = patente;
	}

}
