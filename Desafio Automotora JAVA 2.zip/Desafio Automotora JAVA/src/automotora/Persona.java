package automotora;

public class Persona {
	
	//ATRIBUTOS
	private String rut;
	private String nombre;
	private int edad;
	
	//CONSTRUCTOR
	public Persona (String rut, String nombre, int edad) {
		this.rut = rut;
		this.nombre = nombre;
		this.edad = edad;
	}
	
	public Persona() {
		
	}
	
	//GETS AND SETS
	public String getRut() {
		return rut;
	}

	public void setRut(String rut) {
		this.rut = rut;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}
	
	
}
