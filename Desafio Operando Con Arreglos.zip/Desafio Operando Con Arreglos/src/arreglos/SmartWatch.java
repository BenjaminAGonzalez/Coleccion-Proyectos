package arreglos;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class SmartWatch {

	public static void main(String[] args) {
		
		if (args.length <= 0) {
			System.out.println("Ingrese un valor por favor");
			return;
		}

		int[] pasos = new int[args.length];
		int  Total=0;
		float PromedioTotal=0;
		for(int i = 0; i < args.length; i++) {
			try {
				
				pasos[i] = Integer.parseInt(args[i]);
				
			} catch (Exception ex) {
				
				System.out.println("Se ha encontrado un error");
				System.out.println(ex.getMessage());
				System.exit(-1);
			}

		}
		ArrayList<Integer>PromedioPasos = new ArrayList<Integer>();
		PromedioPasos = clearSteps(pasos);
		
		for(int contador = 0; contador<PromedioPasos.size(); contador++) {
			Total += PromedioPasos.get(contador);
		}
		
		PromedioTotal = Total / PromedioPasos.size();
		System.out.println("El promedio de los pasos es de " + PromedioTotal);
	}
	

	
	public static ArrayList<Integer> clearSteps (int[] pasos){
		
		ArrayList<Integer> removerPasos = new ArrayList<Integer>();
		
		for(int i=0; i<pasos.length; i++) {
			if( pasos[i]<200 || pasos[i] >100000){
				removerPasos.add(pasos[i]);
			}
		}
		
		ArrayList<Integer> pasosFiltrados = new ArrayList<Integer>();
		
		Integer[] boxedArray = Arrays.stream(pasos).boxed().toArray(Integer[]::new);
		
		Collections.addAll(pasosFiltrados,boxedArray);
		
		pasosFiltrados.removeAll(removerPasos);
		
		return pasosFiltrados;
		
	}

}