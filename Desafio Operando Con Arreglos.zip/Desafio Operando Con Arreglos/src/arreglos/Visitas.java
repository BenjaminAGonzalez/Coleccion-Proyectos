package arreglos;

public class Visitas {

	public static void main(String[] args) {

		if (args.length <= 0) {
			System.out.println("Ingrese un valor por favor");
			return;
		}

		Long[] visitas = new Long[args.length];

		for(int i = 0; i < args.length; i++) {
			try {
				
				visitas[i] = Long.parseLong(args[i]);
				
			} catch (Exception ex) {
				System.out.println("Se ha encontrado un error");
				System.out.println(ex.getMessage());
				System.exit(-1);
			}

		}
		System.out.println("Para la entrada anterior, el resultado es " + promedio(visitas));
	}

	public static float promedio (Long  [] visitas) {
		float PromedioTotal = 0;
		long Total = 0;

		for(int contador = 0; contador<visitas.length; contador++) {
			Total += visitas[contador];

		}

		PromedioTotal = Total / visitas.length;

		return  PromedioTotal;

	}

}
