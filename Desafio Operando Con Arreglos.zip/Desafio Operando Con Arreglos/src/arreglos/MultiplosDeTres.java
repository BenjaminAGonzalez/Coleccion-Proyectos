package arreglos;

public class MultiplosDeTres {

	public static void main(String[] args) {
		
		int sumaMultiplos = 0;
		float promedioMultiplos = 0;
		
		if (args.length <= 0) {
			System.out.println("Ingrese un valor por favor");
			return;
		}

		int[] multiplos = new int[args.length];

		for(int i = 0; i < args.length; i++) {
			try {
				multiplos[i] = Integer.parseInt(args[i]);
				
			} catch (Exception ex) {
				System.out.println("Se ha encontrado un error");
				System.out.println(ex.getMessage());
				System.exit(-1);
			}
			
		}
		sumaMultiplos = suma(multiplos);
		promedioMultiplos = promedio(multiplos);
		int resultado =( int)promedioMultiplos;
		System.out.println(sumaMultiplos);
		System.out.println(resultado);
	}

	public static int suma (int[] Numeros) {
		
		int resultado = 0;
		
		for (int i=0 ; i<Numeros.length; i++) {
			if(Numeros[i]%3==0) {
				resultado += Numeros[i];
		}
		
	}
	return resultado;
}

	public static float promedio (int[] Numeros) {
		
		float resultado = 0;
		int contador = 0;
		
		for (int i=0; i<Numeros.length; i++) {
			if(Numeros[i]%3==0) {
				resultado += Numeros[i];
				contador++;
			}
		}
		resultado = resultado/contador;
		return resultado;
	}


}
