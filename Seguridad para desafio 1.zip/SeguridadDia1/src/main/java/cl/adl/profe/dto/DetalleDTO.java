package cl.adl.profe.dto;

public class DetalleDTO {
	
	private String clave;
	private String valor;
	/**
	 * @param clave
	 * @param valor
	 */
	public DetalleDTO(String clave, String valor) {
		super();
		this.clave = clave;
		this.valor = valor;
	}
	/**
	 * 
	 */
	public DetalleDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the clave
	 */
	public String getClave() {
		return clave;
	}
	/**
	 * @return the valor
	 */
	public String getValor() {
		return valor;
	}
	/**
	 * @param clave the clave to set
	 */
	public void setClave(String clave) {
		this.clave = clave;
	}
	/**
	 * @param valor the valor to set
	 */
	public void setValor(String valor) {
		this.valor = valor;
	}
	@Override
	public String toString() {
		return "DetalleDTO [clave=" + clave + ", valor=" + valor + "]";
	}
	
	

}
