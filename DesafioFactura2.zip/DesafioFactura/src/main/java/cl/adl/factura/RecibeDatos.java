package cl.adl.factura;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RecibeDatos
 */
@WebServlet("/RecibeDatos")
public class RecibeDatos extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RecibeDatos() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String nombre, empresa, rut, direccion, ciudad, pais;
		int valvulas, turbo, frenos, cooling, plumillas;
		
		nombre=request.getParameter("nombre");
		empresa=request.getParameter("empresa");
		rut=request.getParameter("rut");
		direccion=request.getParameter("direccion");
		ciudad=request.getParameter("ciudad");
		pais=request.getParameter("pais");
		
		valvulas=Integer.parseInt(request.getParameter("valvulas"));
		turbo=Integer.parseInt(request.getParameter("turbo"));
		frenos=Integer.parseInt(request.getParameter("frenos"));
		cooling=Integer.parseInt(request.getParameter("cooling"));
		plumillas=Integer.parseInt(request.getParameter("plumillas"));
		
		//El ejercicio indica guardar las variables en el response del Servlet, sin embargo, request es el que se encarga de guardar dichas variables con setAttribute
		
		request.setAttribute("Nombre", nombre);
		request.setAttribute("Empresa", empresa);
		request.setAttribute("Rut", rut);
		request.setAttribute("Direccion", direccion);
		request.setAttribute("Ciudad", ciudad);
		request.setAttribute("Pais", pais);
		
		request.setAttribute("Valvulas", valvulas);
		request.setAttribute("Turbo", turbo);
		request.setAttribute("Frenos", frenos);
		request.setAttribute("Cooling", cooling);
		request.setAttribute("Plumillas", plumillas);
		
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("EnviaDatos");
		requestDispatcher.forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
