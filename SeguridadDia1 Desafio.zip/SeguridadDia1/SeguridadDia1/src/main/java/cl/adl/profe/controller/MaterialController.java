package cl.adl.profe.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import cl.adl.profe.dto.MaterialDTO;



@Controller
public class MaterialController {

	@GetMapping("/user")
	public ModelAndView home(HttpSession session) {

		ModelAndView modelAndView = new ModelAndView("user/materiales");
		modelAndView.addObject("detalle", new MaterialDTO());
		modelAndView.addObject("valores",session.getAttribute("valores"));
		return modelAndView;
	}

	@PostMapping("/users")
	public RedirectView home(HttpSession session, @ModelAttribute MaterialDTO detalles) {

		List<MaterialDTO> valores = new ArrayList<>();
		if (session.getAttribute("valores") != null)
			valores.addAll((List<MaterialDTO>)session.getAttribute("valores"));
		valores.add(detalles);
		session.setAttribute("valores", valores);
		return new RedirectView("/user");
	}

}