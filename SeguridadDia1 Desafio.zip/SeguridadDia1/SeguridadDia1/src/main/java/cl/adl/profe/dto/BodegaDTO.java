package cl.adl.profe.dto;

public class BodegaDTO {

	private String bodega;
	private Integer ingreso;


	public BodegaDTO() {
		super();
		
	}
	public BodegaDTO(String bodega, Integer ingreso) {
		super();
		this.bodega = bodega;
		this.ingreso = ingreso;
	}
	/**
	 * @return the bodega
	 */
	public String getBodega() {
		return bodega;
	}
	/**
	 * @param bodega the bodega to set
	 */
	public void setBodega(String bodega) {
		this.bodega = bodega;
	}
	/**
	 * @return the ingreso
	 */
	public Integer getIngreso() {
		return ingreso;
	}
	/**
	 * @param ingreso the ingreso to set
	 */
	public void setIngreso(Integer ingreso) {
		this.ingreso = ingreso;
	}

	@Override
	public String toString() {
		return "BodegaDTO [bodega=" + bodega + ", ingreso=" + ingreso + "]";
	}






}
