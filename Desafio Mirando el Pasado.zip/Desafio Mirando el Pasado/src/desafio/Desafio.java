package desafio;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class Desafio {

	public static void main(String[] args) {

		ArrayList<String> marcas = new ArrayList<>();
		ArrayList<String> posiblesMarcas = new ArrayList<>();
		Set<String> invitados = new TreeSet<>();
		Set<String> posiblesInvitados = new TreeSet<>();
		Map<String, Integer> golosinas = new TreeMap<>();
		Queue<String> juegos = new LinkedList<>();

		marcas.add("McKay");
		marcas.add("Serranita");
		marcas.add("Acuenta");
		marcas.add("Ekono");
		marcas.add("Blizzard");
		marcas.add("Hasbro");
		marcas.add("Calaf");
		marcas.add("Feria Mix");
		marcas.add("Feria Music");
		marcas.add("Telex-Chile");

		posiblesMarcas.add("Nextel");
		posiblesMarcas.add("Otokraus");
		posiblesMarcas.add("Machasa");



		System.out.println(marcas);

		marcas.add("Blokbaster");
		marcas.add("Carrefour");
		marcas.add("Jetix");




		System.out.println(marcas);



		marcas.set(10, "Blockbuster");

		if(marcas.remove("Carrefour")) {
			System.out.println(marcas);
		}else {
			System.out.println("La lista no contenia la marca Carrefour");
		}


		marcas.addAll(posiblesMarcas);
		System.out.println("La cantidad de marcas en nuestra lista final es de " + marcas.size());

		System.out.println(marcas);


		System.out.println("----------------------------------------------");

		invitados.add("Daniel");
		invitados.add("Paola");
		invitados.add("Facundo");
		invitados.add("Pedro");
		invitados.add("Jacinta");
		invitados.add("Florencia");
		invitados.add("Juan Pablo");

		posiblesInvitados.add("Jorge");
		posiblesInvitados.add("Francisco");
		posiblesInvitados.add("Marcos");

		invitados.addAll(posiblesInvitados);

		System.out.println(invitados);

		invitados.remove("Jorge");

		System.out.println("Lista final de invitados");
		System.out.println(invitados);

		System.out.println("----------------------------------------------");

		golosinas.put("Chocman", 100);
		golosinas.put("Trululu", 100);
		golosinas.put("Centella", 100);
		golosinas.put("Kilate", 50);
		golosinas.put("Miti-miti", 30);
		golosinas.put("Traga Traga", 150);
		golosinas.put("Tableton", 5);
		
		golosinas.entrySet().stream().filter(
		precio -> precio.getValue()<100).forEach(System.out::println); //Filtra todos los dulces que cuesten mas de 100

		System.out.println("----------------------------------------------");

		juegos.add("Tombo");
		juegos.add("Congelado");
		juegos.add("Quemaditas");
		juegos.add("Cachipun");
		juegos.add("Pillarse");

		System.out.println("La cantidad de juegos es de " + juegos.size() + " juegos");
		System.out.println(juegos);
		
	}






}
