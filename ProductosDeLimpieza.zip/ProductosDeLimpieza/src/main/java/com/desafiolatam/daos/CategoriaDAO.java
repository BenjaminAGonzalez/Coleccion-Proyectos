package com.desafiolatam.daos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.desafiolatam.dtos.CategoriaDTO;

public class CategoriaDAO {
	
	public List<CategoriaDTO>obtieneCategorias() throws SQLException, ClassNotFoundException{
		
		List<CategoriaDTO> listaDeCategorias = new ArrayList<CategoriaDTO>();
		
		try {
		
		String consultaSQL = "select id_categoria, nombre_categoria from categoria";
		
		Class.forName("org.postgresql.Driver");
		Connection conexion = null;
		
		conexion = DriverManager.getConnection("jdbc:postgresql://127.0.0.1:5432/productos_limpieza","postgres","cbc5537228");
		
			PreparedStatement stmt = conexion.prepareStatement(consultaSQL);
			ResultSet resultado = stmt.executeQuery();
			
			while(resultado.next()) {
				CategoriaDTO categoriaDTO = new CategoriaDTO();
				categoriaDTO.setId_categoria(resultado.getInt("id_categoria"));
				categoriaDTO.setNombre_categoria(resultado.getString("nombre_categoria"));
				listaDeCategorias.add(categoriaDTO);
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return listaDeCategorias;
	}

}
