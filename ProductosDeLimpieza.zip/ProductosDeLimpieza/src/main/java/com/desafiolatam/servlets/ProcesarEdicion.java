package com.desafiolatam.servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.desafiolatam.dtos.ProductoDTO;
import com.desafiolatam.facade.Facade;

/**
 * Servlet implementation class ProcesarEdicion
 */
@WebServlet("/ProcesarEdicion")
public class ProcesarEdicion extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProcesarEdicion() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Integer idProducto = Integer.parseInt(request.getParameter("id_producto"));
		String nombre = request.getParameter("nombre");
		Integer precio = Integer.parseInt(request.getParameter("precio"));
		String descripcion = request.getParameter("descripcion");
		Integer idCategoria = Integer.parseInt(request.getParameter("idCategoria"));
		
		ProductoDTO dto = new ProductoDTO();
		dto.setNombre_producto(nombre);
		dto.setPrecio_producto(precio);
		dto.setDescripcion_producto(descripcion);
		dto.setId_categoria(idCategoria);
		
		Facade facade = new Facade();
		try {
			facade.editarProducto(dto, idProducto);
		}catch(SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		request.getRequestDispatcher("confirmarEdicion.jsp").forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
