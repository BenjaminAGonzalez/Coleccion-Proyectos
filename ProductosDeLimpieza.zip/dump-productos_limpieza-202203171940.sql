--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1
-- Dumped by pg_dump version 14.1

-- Started on 2022-03-17 19:40:10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 3 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- TOC entry 3321 (class 0 OID 0)
-- Dependencies: 3
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 209 (class 1259 OID 33678)
-- Name: categoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categoria (
    id_categoria integer NOT NULL,
    nombre_categoria character varying(50)
);


ALTER TABLE public.categoria OWNER TO postgres;

--
-- TOC entry 211 (class 1259 OID 33696)
-- Name: producto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.producto (
    id_producto integer NOT NULL,
    nombre_producto character varying(75),
    precio_producto integer,
    descripcion_producto character varying(200),
    id_categoria integer
);


ALTER TABLE public.producto OWNER TO postgres;

--
-- TOC entry 210 (class 1259 OID 33695)
-- Name: producto_id_producto_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.producto_id_producto_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.producto_id_producto_seq OWNER TO postgres;

--
-- TOC entry 3322 (class 0 OID 0)
-- Dependencies: 210
-- Name: producto_id_producto_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.producto_id_producto_seq OWNED BY public.producto.id_producto;


--
-- TOC entry 3168 (class 2604 OID 33699)
-- Name: producto id_producto; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.producto ALTER COLUMN id_producto SET DEFAULT nextval('public.producto_id_producto_seq'::regclass);


--
-- TOC entry 3313 (class 0 OID 33678)
-- Dependencies: 209
-- Data for Name: categoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categoria (id_categoria, nombre_categoria) FROM stdin;
1	Detergente Liquido
2	Detergente en polvo
\.


--
-- TOC entry 3315 (class 0 OID 33696)
-- Dependencies: 211
-- Data for Name: producto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.producto (id_producto, nombre_producto, precio_producto, descripcion_producto, id_categoria) FROM stdin;
15	Florinda	7500	Detergente nuevo	1
16	Florinda	7500	Detergente nuevo	1
17	Florinda	500	Detergente nuevo	2
18	Florinda	7500	Detergente nuevo	1
21	Florinda	7500	Detergente nuevo	1
22	Florinda	7500	Detergente nuevo	1
23	Florinda	7500	Detergente nuevo	1
4	Omo	8000	Detergente nuevo	1
5	Omo	8000	Detergente	2
9	Benjamin	500	Detergente Viejo	2
24	Omo	7500	Detergente nuevo	2
8	Omo	9000	Detergente viejo	2
25	Florinda	500	Detergente viejo	2
26	Omo	5000	Detergente	2
13	Cloro	7500	Detergente nuevo	1
\.


--
-- TOC entry 3323 (class 0 OID 0)
-- Dependencies: 210
-- Name: producto_id_producto_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.producto_id_producto_seq', 26, true);


--
-- TOC entry 3170 (class 2606 OID 33682)
-- Name: categoria categoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria
    ADD CONSTRAINT categoria_pkey PRIMARY KEY (id_categoria);


--
-- TOC entry 3172 (class 2606 OID 33701)
-- Name: producto producto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.producto
    ADD CONSTRAINT producto_pkey PRIMARY KEY (id_producto);


--
-- TOC entry 3173 (class 2606 OID 33702)
-- Name: producto producto_id_categoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.producto
    ADD CONSTRAINT producto_id_categoria_fkey FOREIGN KEY (id_categoria) REFERENCES public.categoria(id_categoria);


-- Completed on 2022-03-17 19:40:10

--
-- PostgreSQL database dump complete
--

